"""Run fixed-policy stair evaluations as saved training checkpoints appear."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--python', required=True)
    args = parser.parse_args()
    root = args.root
    env = os.environ.copy()
    env.update(TORCH_DEVICE_BACKEND_AUTOLOAD='0', PYTHONPATH=str(root / 'RLinf'),
               OMP_WAIT_POLICY='PASSIVE', GOMP_SPINCOUNT='0', OPENBLAS_NUM_THREADS='1')
    records = []
    evaluations = [('baseline200_formal', root / 'baseline_a1_200/full_weights.pt',
                    root / 'baseline_a1_200/config.yaml', 1024)]
    for step in (500, 1000, 1500):
        checkpoint = root / f'stairs_ppo/B2_stairs/checkpoints/global_step_{step}/actor/model_state_dict/full_weights.pt'
        evaluations.append((f'ppo{step}_pilot', checkpoint,
                            root / 'stairs_ppo/tensorboard/config.yaml', 128))
    evaluations.append(('ppo1500_formal', evaluations[-1][1], evaluations[-1][2], 1024))
    for name, checkpoint, config, episodes in evaluations:
        deadline = time.monotonic() + 48 * 3600
        while True:
            if time.monotonic() > deadline:
                raise TimeoutError(f'Checkpoint did not appear: {checkpoint}')
            if checkpoint.exists():
                first = checkpoint.stat()
                time.sleep(10)
                second = checkpoint.stat()
                if first.st_size == second.st_size and first.st_mtime_ns == second.st_mtime_ns and second.st_size > 0:
                    break
            time.sleep(30)
        command = [args.python, str(root / 'RLinf/examples/embodiment/go2_mjlab/evaluate_benchmark.py'),
                   '--checkpoint', str(checkpoint), '--training-config', str(config),
                   '--eval-task', 'B2_stairs', '--num-envs', '64', '--num-episodes', str(episodes),
                   '--threads', '1', '--eval-seed', '42', '--output', str(root / 'stairs_eval' / name)]
        with (root / f'eval_{name}.log').open('w') as log:
            result = subprocess.run(command, cwd=root / 'RLinf', env=env, stdout=log, stderr=subprocess.STDOUT)
        records.append({'name': name, 'returncode': result.returncode, 'command': command, 'finished_unix': time.time()})
        (root / 'stairs_eval_watch_results.json').write_text(json.dumps(records, indent=2))
        if result.returncode:
            raise RuntimeError(f'Evaluation failed: {name}; inspect eval_{name}.log')


if __name__ == '__main__':
    main()
