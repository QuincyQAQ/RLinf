"""Run the five-task, three-fine-tuning-seed Go2 benchmark serially."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib

from overnight_stairs import Experiment

TASK_CONFIGS = {
    'B2_stairs': 'go2_mjlab_benchmark_b2_ascend',
    'A1_forward': 'go2_mjlab_benchmark_a1_ascend',
    'A2_omni': 'go2_mjlab_benchmark_a2_ascend',
    'B1_rough': 'go2_mjlab_benchmark_b1_ascend',
    'C2_gap': 'go2_mjlab_benchmark_c2_ascend',
}
SEEDS = (42, 43, 44)


def plan(root):
    return {
        'variant': 'rlinf-mjlab-cross-task-v1-common-base-finetune',
        'tasks': list(TASK_CONFIGS), 'training_seeds': list(SEEDS),
        'policies': 15, 'matrix_cells': 75, 'episodes_per_cell': 1024,
        'seed_order': [42,43,44], 'seed_barrier': 'Finish and export all25cells before next seed',
        'updates_per_policy': 1500, 'total_specialist_updates': 22500,
        'initial_policy': str(root / 'baseline_a1_200/initial_policy.pt'),
        'initial_policy_sha256': json.loads((root / 'baseline_a1_200/manifest.json').read_text())['sha256'],
        'shared_pretraining': 'All branches share A1 checkpoint200; seeds vary fine-tuning, not pretraining',
        'reuse': 'Existing B2seed42 at1500; never select checkpoint using target-test results',
        'num_envs': 4096, 'cpu_workers': 64, 'threads_per_worker': 1,
        'npu_devices': list(range(8, 16)), 'max_parallel_training': 2,
        'max_parallel_evaluation': 2, 'train_eval_serial_per_lane': True,
        'lanes': [[8,9,10,11],[12,13,14,15]],
        'max_days': 10, 'max_training_job_hours': 8, 'max_eval_job_hours': 2,
        'evaluation_seed': 42, 'min_available_ram_gib': 64, 'min_disk_gib': 50,
        'scope': 'Five-task specialist matrix; noMTL; Mjlab port, not numerical IsaacLab replication',
    }


class FullBenchmark(Experiment):
    def __init__(self, root, python):
        self.root, self.python = root, python
        self.destination = root / 'benchmark_full'
        self.destination.mkdir(exist_ok=True)
        self.deadline = time.time() + 10 * 86400
        self.local = threading.local()
        self.local.deadline = self.deadline
        self.mutex = threading.RLock()
        self.cancelled = threading.Event()
        self.starts = {}
        status_path = self.destination / 'status.json'
        if status_path.exists():
            self.state = json.loads(status_path.read_text())
            self.deadline = self.state['deadline_unix']
            self.state['plan'] = plan(root)
        else:
            self.state = {'started_unix': time.time(), 'deadline_unix': self.deadline,
                          'plan': plan(root), 'events': []}
        self.owned = []
        for file, token in [('stairs_ppo_launch.json', 'stairs_ppo'),
                            ('stairs_eval_watch_launch.json', 'stairs_eval_watch.py')]:
            pid = json.loads((root / file).read_text())['pid']
            self.owned.append((pid, token))
            self.starts[pid] = self.start_ticks(pid)
        self.cpu_env = os.environ.copy()
        self.cpu_env.update(TORCH_DEVICE_BACKEND_AUTOLOAD='0', PYTHONPATH=str(root / 'RLinf'),
                            OMP_NUM_THREADS='1', OMP_WAIT_POLICY='PASSIVE',
                            GOMP_SPINCOUNT='0', OPENBLAS_NUM_THREADS='1')
        (self.destination / 'plan.json').write_text(json.dumps(self.state['plan'], indent=2))
        self.note('controller_started', message='Seed barriers42->43->44; preserve existing work; two disjoint4-NPU lanes')

    @staticmethod
    def start_ticks(pid):
        try:
            return Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[19]
        except FileNotFoundError:
            return None

    def alive(self, pid):
        return super().alive(pid) and self.start_ticks(pid) == self.starts.get(pid)

    def note(self, event, **data):
        with self.mutex:
            self._note(event, **data)

    def _note(self, event, **data):
        self.state['events'].append({'event': event, 'unix': time.time(), **data})
        target = self.destination / 'status.json'
        temporary = target.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.state, indent=2)); temporary.replace(target)

    def guard(self):
        if self.cancelled.is_set():
            raise RuntimeError('Another benchmark lane failed; queue cancelled')
        if time.time() > min(self.deadline, getattr(self.local, 'deadline', self.deadline)):
            raise TimeoutError('Benchmark total or per-job time limit reached')
        available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) * 1024
        if available < 64 * 1024**3 or shutil.disk_usage(self.root).free < 50 * 1024**3:
            raise RuntimeError('Resource floor reached:64GiB available RAM /50GiB disk')

    def spawn(self, command, name, env):
        self.guard()
        with (self.destination / f'{name}.log').open('w') as log:
            process = subprocess.Popen(command, cwd=self.root / 'RLinf', env=env,
                                       stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        self.owned.append((process.pid, str(self.root)))
        self.starts[process.pid] = self.start_ticks(process.pid)
        self.note('process_started', name=name, pid=process.pid, command=command)
        return process

    def run_cpu(self, command, name):
        self.local.deadline = time.time() + 2 * 3600
        process = self.spawn(command, name, self.cpu_env)
        while process.poll() is None:
            self.guard(); time.sleep(30)
        if process.returncode:
            raise RuntimeError(f'{name} failed with code{process.returncode}; no automatic retry')
        self.note('process_completed', name=name)

    def evaluate_cell(self, weights, config, output, task):
        self.run_cpu([self.python, str(self.root / 'RLinf/examples/embodiment/go2_mjlab/evaluate_benchmark.py'),
                      '--checkpoint', str(weights), '--training-config', str(config),
                      '--eval-task', task, '--num-envs', '64', '--num-episodes', '1024',
                      '--threads', '1', '--eval-seed', '42', '--output', str(output)],
                     'eval_' + hashlib.sha256(str(weights).encode()).hexdigest()[:10] + '_' + task)

    def validate_checkpoint(self, checkpoint, expected_shards=8):
        import torch
        from torch.distributed.checkpoint import FileSystemReader
        weights = checkpoint / 'actor/model_state_dict/full_weights.pt'
        state = torch.load(weights, map_location='cpu', weights_only=False)
        if state['actor.0.weight'].shape[1] != 235 or not all(torch.isfinite(v).all() for v in state.values()):
            raise ValueError(f'Invalid235-dimensional finite checkpoint: {checkpoint}')
        keys = FileSystemReader(str(checkpoint / 'actor/dcp_checkpoint')).read_metadata().state_dict_metadata
        shards = list((checkpoint / 'actor/dcp_checkpoint').glob('*.distcp'))
        if not any('optimizers.state' in k for k in keys) or len(shards) != expected_shards or not all(s.stat().st_size for s in shards):
            raise ValueError(f'Incomplete optimizer checkpoint: {checkpoint}')
        return weights

    def copy_existing_cell(self, source_row, output):
        row = output / source_row.name
        row.mkdir(parents=True, exist_ok=True)
        for name in ('policy_manifest.json', 'B2_stairs.json', 'summary.json'):
            source = source_row / name
            if not source.is_file():
                raise FileNotFoundError(source)
            shutil.copy2(source, row / name)

    def train(self, task, seed, lane):
        output = self.destination / 'training' / f'{task}_s{seed}'
        self.local.deadline = time.time() + 8 * 3600
        # Check again at every job boundary; do not commandeer occupied devices.
        smi = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, check=True, timeout=20).stdout
        boards = (4, 5) if lane == 0 else (6, 7)
        if any(f'No running processes found in NPU {card}' not in smi for card in boards):
            raise RuntimeError('NPU8–15 occupied at next job boundary; queue stopped')
        env = os.environ.copy(); env.pop('TORCH_DEVICE_BACKEND_AUTOLOAD', None)
        env.update(GO2_PYTHON=self.python, CANN_ENV_FILE='/usr/local/Ascend/ascend-toolkit/set_env.sh',
                   RAY_TMPDIR=f'/tmp/g2bm{task[:2]}s{seed}', MPLCONFIGDIR='/tmp/go2_cross_task_mpl')
        devices = '8-11' if lane == 0 else '12-15'
        placement = 'cluster.component_placement={actor\\,rollout:' + devices + ',env:' + devices + ':0-63}'
        command = ['bash', str(self.root / 'RLinf/examples/embodiment/go2_ascend/run_native.sh'), TASK_CONFIGS[task],
                   'runner.logger.log_path=' + str(output), 'runner.max_steps=1500', 'runner.max_epochs=1500',
                   'runner.save_interval=100', 'env.train.threads=1', f'env.train.seed={seed}', f'actor.seed={seed}', placement,
                   'actor.model.initial_checkpoint=' + str(self.root / 'baseline_a1_200/initial_policy.pt')]
        process = self.spawn(command, f'train_{task}_s{seed}', env)
        self.wait_training(process.pid, output)
        if process.wait() != 0:
            raise RuntimeError(f'Training failed: {task}/seed{seed}')
        checkpoint = output / task / 'checkpoints/global_step_1500'
        weights = self.validate_checkpoint(checkpoint, expected_shards=4)
        import yaml
        config = output / 'tensorboard/config.yaml'
        cfg = yaml.safe_load(config.read_text())
        expected = (task, seed, seed, 235, 1500)
        actual = (cfg['env']['train']['benchmark_task'], cfg['env']['train']['seed'], cfg['actor']['seed'], cfg['actor']['model']['obs_dim'], cfg['runner']['max_steps'])
        if actual != expected:
            raise ValueError(f'Resolved configuration mismatch: {actual} vs{expected}')
        return weights, config

    def export(self):
        self.run_cpu([self.python, str(self.root / 'RLinf/examples/embodiment/go2_mjlab/export_benchmark_matrix.py'),
                      '--results-root', str(self.destination / 'rows')], 'export_matrix_' + str(len(self.state['events'])))

    def parallel(self, functions):
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(function) for function in functions]
            try:
                for future in as_completed(futures):
                    future.result()
            except BaseException:
                self.cancelled.set()
                self.stop_owned()
                raise

    def wait_existing(self):
        self.local.deadline = time.time() + 8 * 3600
        self.wait_training(self.owned[0][0], self.root / 'stairs_ppo')
        checkpoint = self.root / 'stairs_ppo/B2_stairs/checkpoints/global_step_1500'
        self.validate_checkpoint(checkpoint)
        self.local.deadline = time.time() + 2 * 3600
        while self.alive(self.owned[1][0]):
            self.guard(); time.sleep(30)
        result = self.read_cell(self.root / 'stairs_eval/ppo1500_formal')
        self.note('existing_stair_complete', summary=result['summary'])
        if not (self.destination / 'rows/B2_stairs_s42/B2_stairs.json').exists():
            self.copy_existing_cell(self.root / 'stairs_eval/ppo1500_formal/B2_stairs_s42', self.destination / 'rows')

    def baseline(self):
        baseline = self.destination / 'baseline'; baseline.mkdir(exist_ok=True)
        self.read_cell(self.root / 'stairs_eval/baseline200_formal')
        if not (baseline / 'A1_forward_s42/B2_stairs.json').exists():
            self.copy_existing_cell(self.root / 'stairs_eval/baseline200_formal/A1_forward_s42', baseline)
        for task in TASK_CONFIGS:
            if task == 'B2_stairs':
                continue
            cell = baseline / 'A1_forward_s42' / (task + '.json')
            if cell.exists():
                if json.loads(cell.read_text())['summary']['num_episodes'] < 1024:
                    raise ValueError(f'Incomplete formal baseline cell: {cell}')
                continue
            # Adopt an evaluation that survived a controller-only restart.
            adopted = None
            for event in reversed(self.state['events']):
                command = event.get('command', [])
                if (event['event'] == 'process_started' and '--eval-task' in command
                        and command[command.index('--eval-task') + 1] == task
                        and '--output' in command and command[command.index('--output') + 1] == str(baseline)):
                    pid = event['pid']
                    ticks = self.start_ticks(pid)
                    if ticks is not None:
                        actual = Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0', b' ').decode()
                        if str(baseline) not in actual or 'evaluate_benchmark.py' not in actual:
                            raise RuntimeError('Prior evaluation PID identity changed')
                        self.starts[pid] = ticks
                        self.owned.append((pid, 'evaluate_benchmark.py'))
                        self.local.deadline = event['unix'] + 2 * 3600
                        while self.alive(pid):
                            self.guard(); time.sleep(30)
                        if not cell.exists():
                            raise RuntimeError(f'Adopted evaluation failed: {task}; no automatic retry')
                        adopted = pid
                    break
            if adopted is None and not cell.exists():
                self.evaluate_cell(self.root / 'baseline_a1_200/full_weights.pt', self.root / 'baseline_a1_200/config.yaml', baseline, task)
        self.note('baseline_all_tasks_complete')

    def run_row(self, task, seed, lane, existing=False):
        if existing:
            weights = self.root / 'stairs_ppo/B2_stairs/checkpoints/global_step_1500/actor/model_state_dict/full_weights.pt'
            config = self.root / 'stairs_ppo/tensorboard/config.yaml'
        else:
            weights, config = self.train(task, seed, lane)
        for evaluation_task in TASK_CONFIGS:
            if existing and evaluation_task == 'B2_stairs':
                continue
            self.evaluate_cell(weights, config, self.destination / 'rows', evaluation_task)
        self.note('policy_row_complete', train_task=task, seed=seed, lane=lane)

    def lane(self, index, jobs):
        for task, seed, existing in jobs:
            self.run_row(task, seed, index, existing=existing)

    def run(self):
        (self.destination / 'rows').mkdir(exist_ok=True)
        # Baseline CPU evaluations overlap existing training; no additional NPU job.
        self.parallel([self.wait_existing, self.baseline])
        for seed in SEEDS:
            jobs = [(task, seed, False) for task in TASK_CONFIGS
                    if (task, seed) != ('B2_stairs', 42)]
            lane0 = ([('B2_stairs', 42, True)] if seed == 42 else []) + jobs[1::2]
            lane1 = jobs[0::2]
            self.note('seed_phase_started', seed=seed, lane0=lane0, lane1=lane1)
            self.parallel([lambda: self.lane(0, lane0), lambda: self.lane(1, lane1)])
            self.export()
            matrix_path = self.destination / 'rows/matrix_success_rate.json'
            result = json.loads(matrix_path.read_text())
            rows = [row for row in result['per_seed'] if row['train_seed'].endswith('_s' + str(seed))]
            if len(rows) != 5 or any(row[task] is None for row in rows for task in TASK_CONFIGS):
                raise RuntimeError(f'Seed{seed} matrix incomplete; do not advance to next seed')
            snapshot = self.destination / f'seed_{seed}'
            snapshot.mkdir(exist_ok=True)
            (snapshot / 'matrix_per_seed.json').write_text(json.dumps(rows, indent=2))
            for name in ('matrix_success_rate.json', 'matrix_success_rate.csv', 'matrix_success_rate.md'):
                shutil.copy2(self.destination / 'rows' / name, snapshot / name)
            self.note('seed_phase_complete', seed=seed, cells=25, snapshot=str(snapshot))
        matrix = json.loads((self.destination / 'rows/matrix_success_rate.json').read_text())
        if any(row[t] != 3 for row in matrix['seed_counts'] for t in TASK_CONFIGS):
            raise RuntimeError('Matrix incomplete; do not claim completion')
        baseline = json.loads((self.destination / 'baseline/A1_forward_s42/summary.json').read_text())
        comparison = []
        for row in matrix['mean']:
            task = row['train_task']
            before, after = baseline[task]['success_rate'], row[task]
            comparison.append({'task': task, 'baseline_success_rate': before,
                               'ppo1500_mean_success_rate': after,
                               'gain_percentage_points': 100 * (after - before),
                               'fine_tuning_seeds': 3})
        (self.destination / 'diagonal_baseline_vs_ppo.json').write_text(json.dumps(comparison, indent=2))
        self.note('complete', policies=15, cells=75, episodes_per_cell_at_least=1024)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--python', required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.check:
        print(json.dumps(plan(args.root), indent=2)); return
    with (args.root / 'full_benchmark.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        benchmark = FullBenchmark(args.root, args.python)
        try:
            benchmark.run()
        except (Exception, KeyboardInterrupt) as error:
            benchmark.note('stopped_with_error', error=repr(error))
            benchmark.stop_owned()
            raise


if __name__ == '__main__':
    main()
