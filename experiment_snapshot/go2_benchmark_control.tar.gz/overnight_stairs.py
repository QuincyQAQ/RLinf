"""Bounded, serial continuation of the recorded Go2 stair experiment."""
import argparse
import fcntl
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time


class Experiment:
    def __init__(self, root, python):
        self.root, self.python = root, python
        self.deadline = time.time() + 12 * 3600
        self.state = {'started_unix': time.time(), 'deadline_unix': self.deadline,
                      'max_total_task_updates': 3000, 'events': []}
        self.owned = []
        self.cpu_env = os.environ.copy()
        self.cpu_env.update(TORCH_DEVICE_BACKEND_AUTOLOAD='0', PYTHONPATH=str(root / 'RLinf'),
                            OMP_WAIT_POLICY='PASSIVE', GOMP_SPINCOUNT='0', OPENBLAS_NUM_THREADS='1')
        for file in ('stairs_ppo_launch.json', 'stairs_eval_watch_launch.json'):
            record = json.loads((root / file).read_text())
            self.owned.append((record['pid'], 'stairs_ppo' if 'ppo_launch' in file else 'stairs_eval_watch.py'))
        self.note('started', policy='No task, reward, success threshold or PPO hyperparameter changes; at most3000 updates; no automatic retries')

    def note(self, event, **data):
        self.state['events'].append({'event': event, 'unix': time.time(), **data})
        target = self.root / 'overnight_status.json'
        temp = target.with_suffix('.tmp')
        temp.write_text(json.dumps(self.state, indent=2)); temp.replace(target)

    @staticmethod
    def alive(pid):
        try:
            return Path(f'/proc/{pid}/stat').read_text().split()[2] != 'Z'
        except FileNotFoundError:
            return False

    def stop_owned(self):
        for pid, token in self.owned:
            if not self.alive(pid):
                continue
            command = Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0', b' ').decode()
            if str(self.root) in command and token in command and os.getpgid(pid) == pid:
                os.killpg(pid, signal.SIGTERM)
                self.note('stop_requested', pid=pid, reason='Only this experiment process group')
                time.sleep(10)
                try:
                    os.killpg(pid, 0)
                    os.killpg(pid, signal.SIGKILL)
                    self.note('forced_group_stop', pid=pid)
                except ProcessLookupError:
                    pass

    def guard(self):
        available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) * 1024
        if time.time() > self.deadline:
            raise TimeoutError('12-hour experiment limit reached; preserve latest saved checkpoints')
        if available < 64 * 1024**3 or shutil.disk_usage(self.root).free < 50 * 1024**3:
            raise RuntimeError('Resource floor reached: need64GiB available RAM and50GiB free disk')

    def wait_training(self, pid, output):
        from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
        started = time.time()
        while self.alive(pid):
            self.guard()
            events = list((output / 'tensorboard').glob('events.out*'))
            latest = max((p.stat().st_mtime for p in events), default=started)
            for event_path in events:
                accumulator = EventAccumulator(str(event_path))
                accumulator.Reload()
                for tag in ('train/actor/analytic_kl', 'train/critic/value_loss'):
                    if tag in accumulator.Tags()['scalars']:
                        values = accumulator.Scalars(tag)
                        if values and not math.isfinite(values[-1].value):
                            raise ValueError(f'Nonfinite training metric: {tag}')
            if time.time() - latest > 20 * 60:
                raise TimeoutError('Training has produced no event updates for20minutes')
            time.sleep(30)
        self.note('training_process_exited', pid=pid)

    def read_cell(self, output):
        cells = list(output.rglob('B2_stairs.json'))
        if len(cells) != 1:
            raise RuntimeError(f'Expected one completed evaluation cell in {output}, got{len(cells)}')
        result = json.loads(cells[0].read_text())
        if result['summary']['num_episodes'] < 1024:
            raise RuntimeError('Formal decision requires at least1024episodes')
        return result

    def evaluate(self, checkpoint, config, name, episodes=1024, seed=42):
        self.guard()
        output = self.root / 'stairs_eval' / name
        command = [self.python, str(self.root / 'RLinf/examples/embodiment/go2_mjlab/evaluate_benchmark.py'),
                   '--checkpoint', str(checkpoint), '--training-config', str(config), '--eval-task', 'B2_stairs',
                   '--num-envs', '64', '--num-episodes', str(episodes), '--threads', '1', '--eval-seed', str(seed), '--output', str(output)]
        with (self.root / f'eval_{name}.log').open('w') as log:
            process = subprocess.Popen(command, cwd=self.root / 'RLinf', env=self.cpu_env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        self.owned.append((process.pid, 'evaluate_benchmark.py'))
        self.note('evaluation_started', pid=process.pid, command=command)
        began = time.time()
        while process.poll() is None:
            self.guard()
            if time.time() - began > 2 * 3600:
                raise TimeoutError(f'Evaluation exceeded2hours: {name}')
            time.sleep(30)
        if process.returncode:
            raise RuntimeError(f'Evaluation failed without retry: {name}, code{process.returncode}')
        self.note('evaluation_completed', name=name)
        return output

    def run(self):
        first = self.owned[0][0]
        self.wait_training(first, self.root / 'stairs_ppo')
        checkpoint1500 = self.root / 'stairs_ppo/B2_stairs/checkpoints/global_step_1500'
        if not (checkpoint1500 / 'actor/model_state_dict/full_weights.pt').exists():
            raise RuntimeError('Original training exited without final1500checkpoint')
        watch = self.owned[1][0]
        began = time.time()
        while self.alive(watch):
            self.guard()
            if time.time() - began > 2 * 3600:
                raise TimeoutError('Existing evaluation queue exceeded2hours after training completion')
            time.sleep(30)
        result = self.read_cell(self.root / 'stairs_eval/ppo1500_formal')
        baseline = self.read_cell(self.root / 'stairs_eval/baseline200_formal')
        summary = result['summary']
        self.note('decision1500', baseline=baseline['summary'], result=summary)
        combined = summary['stairs_tracking_and_pass_success_rate']
        passed = summary['stairs_pass_success_rate']
        if combined >= 0.8:
            self.evaluate(checkpoint1500 / 'actor/model_state_dict/full_weights.pt',
                          self.root / 'stairs_ppo/tensorboard/config.yaml', 'ppo1500_seed43_check', episodes=256, seed=43)
            self.note('complete', reason='Combined success>=80%; ran independent evaluation seed check; no extra training')
            return
        if passed < 0.05 or summary['failure_rate'] > 0.5:
            self.note('complete', reason='No useful traversal capability or failure rate>50%; stop rather than blindly extend or change task')
            return
        # The DCP resume keeps model, moments, optimizer and scheduler state.
        from torch.distributed.checkpoint import FileSystemReader
        import torch
        actor = checkpoint1500 / 'actor'
        weights = torch.load(actor / 'model_state_dict/full_weights.pt', map_location='cpu', weights_only=False)
        if not all(torch.isfinite(t).all() for t in weights.values()):
            raise ValueError('Nonfinite checkpoint; continuation cancelled')
        keys = FileSystemReader(str(actor / 'dcp_checkpoint')).read_metadata().state_dict_metadata
        if not any('optimizers.state' in key for key in keys):
            raise ValueError('No optimizer state; continuation cancelled')
        # Never start another device job while either recorded job group exists.
        for pid, _ in self.owned:
            if self.alive(pid):
                raise RuntimeError(f'Owned process{pid} still running; no overlapping training')
        smi = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, check=True).stdout
        (self.root / 'overnight_pre_resume_npu.txt').write_text(smi)
        if any(f'No running processes found in NPU {card}' not in smi for card in (4, 5, 6, 7)):
            raise RuntimeError('NPU8–15 no longer idle; continuation cancelled')
        env = os.environ.copy()
        env.pop('TORCH_DEVICE_BACKEND_AUTOLOAD', None)
        env.update(GO2_PYTHON=self.python, CANN_ENV_FILE='/usr/local/Ascend/ascend-toolkit/set_env.sh',
                   RAY_TMPDIR='/tmp/g2ctb2ext', MPLCONFIGDIR='/tmp/go2_cross_task_mpl')
        command = ['bash', str(self.root / 'RLinf/examples/embodiment/go2_ascend/run_native.sh'),
                   'go2_mjlab_benchmark_b2_ascend', 'runner.logger.log_path=' + str(self.root / 'stairs_ppo_extended'),
                   'runner.max_steps=3000', 'runner.max_epochs=3000', 'env.train.threads=1',
                   'actor.model.initial_checkpoint=null', '+runner.resume_dir=' + str(checkpoint1500)]
        with (self.root / 'stairs_ppo_extended_console.log').open('w') as log:
            process = subprocess.Popen(command, cwd=self.root / 'RLinf', env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        self.owned.append((process.pid, 'stairs_ppo_extended'))
        self.note('continuation_started', pid=process.pid, command=command)
        self.wait_training(process.pid, self.root / 'stairs_ppo_extended')
        if process.wait() != 0:
            raise RuntimeError('Continuation failed; no automatic retry')
        final = self.root / 'stairs_ppo_extended/B2_stairs/checkpoints/global_step_3000/actor/model_state_dict/full_weights.pt'
        output = self.evaluate(final, self.root / 'stairs_ppo_extended/tensorboard/config.yaml', 'ppo3000_formal')
        self.note('complete', baseline=baseline['summary'], result1500=summary, result3000=self.read_cell(output)['summary'])


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--python', required=True)
    p.add_argument('--check', action='store_true')
    a = p.parse_args()
    for name in ('stairs_ppo_launch.json', 'stairs_eval_watch_launch.json', 'baseline_a1_200/manifest.json'):
        json.loads((a.root / name).read_text())
    if a.check:
        return
    with (a.root / 'overnight.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        experiment = Experiment(a.root, a.python)
        try:
            experiment.run()
        except (Exception, KeyboardInterrupt) as error:
            experiment.note('stopped_with_error', error=repr(error))
            experiment.stop_owned()
            raise


if __name__ == '__main__':
    main()
