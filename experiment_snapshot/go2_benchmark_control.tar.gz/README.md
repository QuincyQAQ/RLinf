# Go2 Cross-Task Evaluation Matrix 接入记录

来源：用户指定的 [评估协议](https://github.com/viktoriageorrg04/bsc-thesis-multi-task-RL-env/blob/main/docs/eval_protocol.md) 与 [合并成功率矩阵](https://github.com/viktoriageorrg04/bsc-thesis-multi-task-RL-env/blob/main/results_seeded_combined/combined_success_rate.json)。源码固定 commit `743ac04d9543b04b7854f1100bfa0cc69c993106`，本地位于 `../../benchmarks/bsc-thesis-multi-task-RL-env`，未修改原仓库。

## 当前已完成与未完成

已核验五任务阈值，逐条重算来源仓库90个详细结果文件、92388个回合；成功标签与当前阈值无不一致，汇总指标匹配；合并矩阵每单元格的三种子均值/样本标准差重算通过。CPU计分器对五任务随机向量终止/超时流与原实现逐回合一致。参考数值仅属于来源项目，不是我们的训练结果。

用户已确认采用独立 Mjlab 移植版。五个真实CPU物理任务、235维观测、终止/重置均已本机短测通过，旧Flat回归通过；hkust的CPU A1探针也已通过。尚未开始正式训练或正式矩阵评估。原benchmark是Isaac Lab，现有hkust长训练是CPU Mjlab + RLinf + NPU。既有Flat模型为47维，原benchmark全部任务为235维（含187维高度扫描），不能直接补零/截断/重命名成A1或A2策略。正式代码位于 RLinf/rlinf/envs/sim/go2_mjlab/benchmark*.py，含五任务环境适配；评估、矩阵导出入口和六份新配置均在RLinf仓库内。当前分支 feat/go2-mjlab-cross-task，已本地提交 fba201a，未推送。

此前五地形单种子零样本试验仅保留为历史辅助结果，不再作为新benchmark主要验收。cross-task矩阵本身的非对角单元格仍是跨任务迁移评估；若要完全没有未训练任务，必须训练覆盖全部五任务的MTL策略，再报告对应MTL行，不能只改评估名称。

## 五任务与成功规则

全回合记录（包括起步），每一步平面速度L2误差和偏航绝对误差均低于阈值且非失败时计为成功步。回合不发生失败终止，并且成功步占比达标，才算回合成功。不是RMSE，也不是到达某个终点/跨过全部台阶的几何验收。

| 任务 | 场景/指令 | 平面误差上限 m/s | 偏航误差上限 rad/s | 成功步占比下限 |
|---|---|---:|---:|---:|
| A1_forward | 平地前进，vx 0.35–1.0，20%站立指令 | 0.20 | 0.40 | 85% |
| A2_omni | 平地全向、航向命令，5%站立指令 | 0.25 | 0.50 | 80% |
| B1_rough | 随机粗糙地形，全向/航向命令 | 0.35 | 0.60 | 75% |
| B2_stairs | 倒金字塔阶梯，高4–16cm，vx 0.4–0.9 | 0.40 | 0.70 | 70% |
| C2_gap | 环形沟隙，宽0–20cm，vx 0.4–0.8 | 0.45 | 0.75 | 65% |

A2/B1横向范围±1m/s、偏航范围±1rad/s，航向命令还会影响实际偏航目标。地形与随机化不能用此前20×20m固定试验替代。C2代码实际是100%gap；部分注释仍写70/30，实施以固定源码配置为准。

原文档快速例子为64环境、至少256回合；用户指定合并结果的seeded脚本请求至少1024回合/单元格，实际向量批次会超出1024。原数据为每个训练类型3个训练种子，不能把同一模型换3个评估种子冒充3次独立训练。

## 输出约定

一个训练策略×五任务为1×5行；五个专项策略构成5×5；再加MTL为6×5。缺少某策略时留空并标为未训练，不能填0或复制其他checkpoint。每个单元格保存完整回合，再汇总：success_rate、failure_rate、mean_alive_time_s、mean_success_step_ratio、mean_lin_vel_error、mean_ang_vel_error、num_episodes。训练种子间单元格标准差使用ddof=1。

`reference/REFERENCE_MATRIX.md` 与 `reference/upstream_combined_success_rate.json` 是他人参考结果；`reference/source_audit.json` 保存逐文件核验和SHA256来源。尚无本项目benchmark矩阵结果。

原结果std字段中的mean_over_eval_tasks实际上是“各任务均值之间的标准差”，不是“每训练种子宏平均的标准差”。不能将其当作多种子总分置信度。原evaluate.py在env.step之后读取误差，移植时应明确终止自动重置、命令重采样的时间对齐，不能暗改后声称逐数字复现。

## 后续实施依赖

1. 已确认移植 Mjlab 版本，差异说明见 RLinf/examples/embodiment/go2_mjlab/BENCHMARK.zh-CN.md。不能宣称直接复现原百分数。
2. 已实现五任务235/235维契约，本机全部CPU短测、旧47/74维回归和沟隙射线几何检查通过，见probes/。20项单元测试通过、1项在单测解释器跳过，另在conda mjlab验证了真实物理。
3. hkust新目录 /data1/qli736/go2_cross_task_v1。用户授权保存并暂停旧训练后，已停止旧 PID1894267 进程组；完整恢复点为原任务 global_step_3500。新版本原生 RLinf 单 NPU8、16环境、3更新全部通过，最终 global_step_3 的235维权重有限、归一化count=1152、优化器metadata已验证，短测进程已退出。结果及旧恢复记录在 artifacts/{smoke_a1_result.json,old_training_pause.json}。旧训练仍暂停，正式benchmark训练尚未启动。MTL不在本版五专项环境内。
4. 每任务独立进程做交叉评估，先短测，再执行多训练种子、1024+回合正式矩阵。

历史核实：最早本机Unitree RL Lab使用Isaac Lab；hkust迁移后使用MuJoCo，当前版本为Mjlab，NPU负责推理/PPO。记录见 `../mjlab_native/launch.json`、`../../RLinf/examples/embodiment/config/go2_mjlab_ppo_ascend.yaml`。框架名称、模拟器、计算设备是三件事。

## 复跑审计与测试

```bash
PYTHONPATH="../../RLinf" /home/quincylee/miniconda3/envs/mjlab/bin/python audit_reference.py
PYTHONPATH="../../RLinf" /home/quincylee/miniconda3/envs/mjlab/bin/python test_metrics.py
```

以上不启动模拟器、不访问真机、不提交训练任务。本目录证据文件在RLinf Git仓库之外；实现代码已在RLinf本地提交 fba201a，未推送。

## 保留旧参数

legacy_parameters/ 保存原四份配置及原训练解析配置，并有SHA256核验；原配置本身未改动。probes/保存新五任务与旧任务回归证据。原始零样本地形视频和数据仍保留在mjlab_deployment_audit/，不混入新benchmark矩阵。

## 当前实验：基础策略 → 台阶 PPO

A1在200次检查点保存并暂停，B2从相同完整policy和normalizer开始原生PPO，优化器重置。先1500次更新、4096环境、8NPU，每100保存。参考项目README专项示例为1500次；本次环境数量和模拟器不同，不宣称严格复刻。5000为后续可选上限，尚未启动扩轮次。

CPU线程短测结果见artifacts/perf_cpu_result.json，选择每worker1线程。启动和初始权重来源见artifacts/stairs_ppo_launch.json与manifest.json。自动评估脚本stairs_eval_watch.py保存固定baseline和500/1000/1500对比。

B2新增实际台阶通过指标：相对地形原点x达到3.3m，穿越前始终abs(y)<=2.7m，并存活完整20秒。此门槛是8m地块、1m边框外落脚平台的身体中心0.3m余量，不直接验证四脚过线。仅使用pre-action非复位状态，最后终止动作才过线保守不计。通过率与原跟踪率单独报告，组合成功要求两者同时满足；这不是参考论文原有指标。

## 完整自动队列（最新，替代仅台阶夜间续训）

full_benchmark_queue.py与overnight_stairs.py配套：5专项×3后训练种子，共15策略/75单元，每策略1500更新，每单元1024回合。共享冻结A1_200基础策略，先评基础策略全部五任务；重用正在训练的B2seed42。当前B2完成后，设备8–11与12–15两条lane并行，每lane64CPUworker×1线程；0–7被vLLM占用，不动。单任务/总资源保护及计划见远端benchmark_full/plan.json，当前状态status.json；总上限10天，不再使用旧12h/3000台阶续训。CLI配置30组合验证与批量可整除检查通过，真实4NPU启动待现有B2完成。最终导出三seed5×5矩阵及baseline对角提升；台阶通过附加指标不替代原跟踪矩阵。
