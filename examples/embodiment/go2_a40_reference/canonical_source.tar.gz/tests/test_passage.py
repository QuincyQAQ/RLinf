"""CPU checks using the original terrain generators and reset-time episode capture."""
from __future__ import annotations

import ast
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch
import trimesh

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "a40"))
from passage_metrics import Obstacle, PassageTracker, obstacle_from_mesh, summarize_passage
from evaluate_dual import PassageRuntime, capture_geometry
import reference


def author_function(path, name, namespace):
    tree = ast.parse(path.read_text())
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    module = ast.Module(body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), fn], type_ignores=[])
    exec(compile(ast.fix_missing_locations(module), str(path), "exec"), namespace)
    return namespace[name]


def actual_mesh(task, difficulty=.5):
    directory = ROOT / "IsaacLab/source/isaaclab/isaaclab/terrains/trimesh"
    namespace = {"np": np, "trimesh": trimesh}
    author_function(directory / "utils.py", "make_border", namespace)
    name = "inverted_pyramid_stairs_terrain" if task == "B2" else "gap_terrain"
    generate = author_function(directory / "mesh_terrains.py", name, namespace)
    cfg = SimpleNamespace(size=(8., 8.), border_width=1., platform_width=3. if task == "B2" else 2.,
                          holes=False, step_width=.3, step_height_range=(.04, .16), gap_width_range=(0., .2))
    meshes, origin = generate(difficulty, cfg)
    mesh = trimesh.util.concatenate(meshes)
    mesh.apply_translation((-4., -4., 0.))
    origin -= np.array([4., 4., 0.])
    return mesh, origin, name


def gap_tracker(n=1):
    mesh, origin, name = actual_mesh("C2", 1.)
    geom = obstacle_from_mesh(mesh, origin, "C2", 0, 0, name)
    tracker = PassageTracker({(0, 0): geom}, n, .02)
    root, feet = state([0.] * n)
    tracker.begin(root, feet, torch.zeros(n, 3), torch.zeros(n, dtype=torch.long), torch.zeros(n, dtype=torch.long))
    return tracker


def state(xs):
    root = torch.tensor([[x, 0., .37] for x in xs], dtype=torch.float32)
    feet = root[:, None, :].repeat(1, 4, 1)
    feet[:, :, 2] = .025
    feet[:, :, 0] += torch.tensor([.2, .2, -.2, -.2])
    feet[:, :, 1] += torch.tensor([.15, -.15, .15, -.15])
    return root, feet


def walk(tracker, end=1.6, hold=12, front_only=False):
    for x in np.linspace(.1, end, 20).tolist() + [end] * hold:
        root, feet = state([x] * tracker.n)
        if front_only:
            feet[:, 2:, 0] = .9
        tracker.observe(root, feet, torch.full((tracker.n, 4), 10.), torch.ones(tracker.n))


def finish(tracker, failure=False, tracking=True):
    rows = [{"episode_success": tracking, "termination_reason": "failure" if failure else "time_out"} for _ in range(tracker.n)]
    return tracker.finish(torch.arange(tracker.n), rows)


class GeometryTests(unittest.TestCase):
    def test_actual_stair_mesh_detects_all_rises_and_landing(self):
        for difficulty in (0., .37, 1.):
            mesh, origin, name = actual_mesh("B2", difficulty)
            geom = obstacle_from_mesh(mesh, origin, "B2", 0, 4, name)
            self.assertAlmostEqual(geom.inner_radius, 1.2)
            self.assertAlmostEqual(geom.outer_radius, 3.)
            self.assertEqual(geom.stair_rises, 7)
            self.assertAlmostEqual(geom.rise, 7 * (.04 + .12 * difficulty))
            self.assertAlmostEqual(geom.landing_height, geom.rise)

    def test_actual_gap_and_cached_mesh_have_same_measured_width(self):
        for difficulty in (.1, .5, 1.):
            mesh, origin, name = actual_mesh("C2", difficulty)
            expected = obstacle_from_mesh(mesh, origin, "C2", 2, 3, name)
            self.assertAlmostEqual(expected.outer_radius - expected.inner_radius, .2 * difficulty)
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / "mesh.obj"
                mesh.export(path)
                cached = trimesh.load_mesh(path, process=False)
                measured = obstacle_from_mesh(cached, origin, "C2", 2, 3, name)
                self.assertAlmostEqual(measured.outer_radius, expected.outer_radius, places=5)

    def test_unknown_or_asymmetric_geometry_fails_closed(self):
        mesh, origin, name = actual_mesh("C2")
        with self.assertRaises(ValueError):
            obstacle_from_mesh(mesh, origin, "C2", 0, 0, "random_rough")
        mesh.apply_scale((1., 1.1, 1.))
        with self.assertRaises(ValueError):
            obstacle_from_mesh(mesh, origin, "C2", 0, 0, name)

    def test_capture_uses_original_generator_once_and_does_not_mutate_mesh(self):
        mesh, origin, _ = actual_mesh("C2")
        before = mesh.vertices.copy()
        calls = []
        class Generator:
            def _add_sub_terrain(self, *args):
                calls.append(args)
                return "original"
        cfg = SimpleNamespace(scene=SimpleNamespace(terrain=SimpleNamespace(terrain_generator=SimpleNamespace(class_type=Generator))))
        captured = {}
        capture_geometry(cfg, "C2", captured)
        result = cfg.scene.terrain.terrain_generator.class_type()._add_sub_terrain(
            mesh, origin, 0, 0, SimpleNamespace(function=SimpleNamespace(__name__="gap_terrain")))
        self.assertEqual(result, "original")
        self.assertEqual(len(calls), 1)
        self.assertTrue(np.array_equal(mesh.vertices, before))


class PassageTests(unittest.TestCase):
    def test_stationary_and_front_feet_only_do_not_pass(self):
        for end, front in ((0., False), (1.6, True)):
            tracker = gap_tracker()
            walk(tracker, end=end, front_only=front)
            self.assertFalse(finish(tracker)[0]["physical_obstacle_passage"])

    def test_landing_and_tracking_are_independent_and_share_denominator(self):
        tracker = gap_tracker(2)
        walk(tracker)
        rows = finish(tracker, tracking=False)
        report = summarize_passage(rows)
        self.assertEqual(report["physical_obstacle_passage_rate"], 1.)
        self.assertEqual(report["joint_tracking_and_passage_success_rate"], 0.)
        self.assertEqual(report["physical_measured_episodes"], 2)

    def test_failure_after_crossing_invalidates_episode_success(self):
        tracker = gap_tracker()
        walk(tracker)
        self.assertGreaterEqual(int(tracker.passed_at[0]), 0)
        self.assertFalse(finish(tracker, failure=True)[0]["physical_obstacle_passage"])

    def test_teleport_and_start_on_far_bank_cannot_pass(self):
        tracker = gap_tracker()
        root, feet = state([1.6])
        for _ in range(15):
            tracker.observe(root, feet, torch.full((1, 4), 10.), torch.ones(1))
        row = finish(tracker)[0]
        self.assertTrue(row["passage_evidence"]["unexpected_position_jump"])
        self.assertFalse(row["physical_obstacle_passage"])
        tracker.begin(root, feet, torch.zeros(1, 3), torch.tensor([0]), torch.tensor([0]))
        walk(tracker, end=1.6)
        self.assertFalse(finish(tracker)[0]["physical_obstacle_passage"])

    def test_airborne_or_short_landing_is_not_success(self):
        tracker = gap_tracker()
        walk(tracker, hold=0)
        self.assertFalse(finish(tracker)[0]["physical_obstacle_passage"])
        tracker = gap_tracker()
        for x in np.linspace(0., 1.6, 20).tolist() + [1.6] * 15:
            root, feet = state([x])
            tracker.observe(root, feet, torch.zeros(1, 4), torch.ones(1))
        self.assertFalse(finish(tracker)[0]["physical_obstacle_passage"])

    def test_zero_width_gap_is_unmeasurable_not_free_success(self):
        mesh, origin, name = actual_mesh("C2", 0.)
        geometry = obstacle_from_mesh(mesh, origin, "C2", 0, 0, name)
        tracker = PassageTracker({(0, 0): geometry}, 1, .02)
        root, feet = state([0.])
        tracker.begin(root, feet, torch.zeros(1, 3), torch.tensor([0]), torch.tensor([0]))
        walk(tracker)
        report = summarize_passage(finish(tracker))
        self.assertIsNone(report["physical_obstacle_passage_rate"])
        self.assertFalse(report["required_obstacle_metrics_complete"])

    def test_nonmonotonic_episode_completion_does_not_mix_env_ids(self):
        tracker = gap_tracker(2)
        walk(tracker)
        rows = tracker.finish(torch.tensor([1]), [{"episode_success": True, "termination_reason": "time_out"}])
        self.assertEqual(rows[0]["env_id"], 1)
        self.assertEqual(rows[0]["episode_index"], 0)
        rows = tracker.finish(torch.tensor([0]), [{"episode_success": False, "termination_reason": "failure"}])
        self.assertEqual(rows[0]["env_id"], 0)
        self.assertFalse(rows[0]["physical_obstacle_passage"])

    def test_invalid_episode_evidence_and_duplicates_are_rejected(self):
        tracker = gap_tracker()
        walk(tracker)
        rows = finish(tracker)
        with self.assertRaises(ValueError):
            summarize_passage(rows + rows)
        rows[0]["termination_reason"] = "failure"
        with self.assertRaises(ValueError):
            summarize_passage(rows)

    def test_both_training_lanes_select_dual_evaluator_only_for_obstacles(self):
        for task in reference.SOURCES:
            argv = reference.evaluation_argv(task, 0, Path("/tmp/model.pt"), Path("/tmp/python"), Path("/tmp/out"))
            self.assertEqual(Path(argv[1]).name, "evaluate_dual.py" if task in {"B2", "C2"} else "evaluate.py")
            self.assertNotIn("--seed", argv)


class RuntimeTests(unittest.TestCase):
    def test_terminal_state_is_captured_before_reset_and_tracking_is_unchanged(self):
        # The original tracker and the real runtime hooks run on the same fake SDK
        # tensors. Each timeout teleports the source tile by 100 m and changes level.
        spec = importlib.util.spec_from_file_location("go2_original_success", ROOT / "benchmark/envs/success.py")
        success = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = success
        spec.loader.exec_module(success)
        names = ["FL_foot", "FR_foot", "RL_foot", "RR_foot"]

        class Scene(dict):
            pass

        class FakeEnv:
            num_envs, device, step_dt = 2, "cpu", .02

            def __init__(self):
                self.scene = Scene()
                self.scene.terrain = SimpleNamespace(env_origins=torch.zeros(2, 3),
                    terrain_levels=torch.zeros(2, dtype=torch.long), terrain_types=torch.zeros(2, dtype=torch.long))
                self.scene["robot"] = SimpleNamespace(data=SimpleNamespace(),
                    find_bodies=lambda *_args, **_kwargs: (list(range(4)), names))
                self.scene["contact_forces"] = SimpleNamespace(data=SimpleNamespace(
                    net_forces_w=torch.tensor([[[0., 0., 10.]] * 4] * 2)),
                    find_bodies=lambda *_args, **_kwargs: (list(range(4)), names))
                self.clock = torch.zeros(2, dtype=torch.long)
                self._update()

            def _update(self):
                root, feet = state([min(int(self.clock[0]) * .1, 1.6), 0.])
                data = self.scene["robot"].data
                data.root_pos_w = root + self.scene.terrain.env_origins
                data.body_pos_w = feet + self.scene.terrain.env_origins[:, None, :]
                data.projected_gravity_b = torch.tensor([[0., 0., -1.]] * 2)

            def _reset_idx(self, ids):
                self.clock[ids] = 0
                self.scene.terrain.env_origins[ids, 0] += 100.
                self.scene.terrain.terrain_levels[ids] = 1
                self._update()

            def step(self, actions):
                self.clock += 1
                self._update()
                terminated = torch.zeros(2, dtype=torch.bool)
                timeouts = self.clock >= 30
                if timeouts.any():
                    self._reset_idx(timeouts.nonzero().flatten())
                return None, torch.zeros(2), terminated, timeouts, {}

        mesh, origin, name = actual_mesh("C2", 1.)
        geometries = {(level, 0): obstacle_from_mesh(mesh, origin, "C2", level, 0, name) for level in (0, 1)}

        def collect(instrumented):
            env = FakeEnv()
            original_step = env.step
            runtime = PassageRuntime(env, geometries) if instrumented else None
            tracker = success.EpisodeStatsTracker(2, .02)
            rows = []
            rng_before = torch.get_rng_state().clone()
            for _ in range(60):
                _, _, terminated, truncated, _ = env.step(torch.zeros(2, 12))
                batch = tracker.update(step_success=torch.tensor([True, False]),
                    lin_err_xy=torch.tensor([.1, .6]), ang_err_z=torch.zeros(2),
                    terminated=terminated, truncated=truncated, task_id=4, family_id=2)
                if runtime:
                    runtime.tracker.finish((terminated | truncated).nonzero().flatten(), batch)
                rows.extend(batch)
            self.assertTrue(torch.equal(torch.get_rng_state(), rng_before))
            if runtime:
                runtime.close()
                self.assertEqual(env.step, original_step)
            return rows

        original, augmented = collect(False), collect(True)
        self.assertEqual(len(original), 4)
        for before, after in zip(original, augmented):
            self.assertEqual(before, {key: after[key] for key in before})
        self.assertEqual([e["physical_obstacle_passage"] for e in augmented], [True, False, True, False])
        self.assertEqual(augmented[0]["passage_evidence"]["geometry_key"], "0,0")
        self.assertEqual(augmented[2]["passage_evidence"]["geometry_key"], "1,0")
        self.assertAlmostEqual(augmented[0]["passage_evidence"]["end_root_relative_m"][0], 1.6, places=4)
        self.assertFalse(augmented[0]["passage_evidence"]["unexpected_position_jump"])

    def test_reference_report_recalculates_passage_and_rejects_corrupt_summary(self):
        tracker = gap_tracker(2)
        walk(tracker)
        rows = finish(tracker)
        for row in rows:
            row["termination_reason"] = "time_out"
        # Each identity is unique, even when vectorized completion overshoots the minimum.
        episodes = []
        for repeat in range(512):
            for row in rows:
                episodes.append(dict(row, episode_index=repeat))
        physical = summarize_passage(episodes)
        summary = dict(num_episodes=1024, success_rate=1., failure_rate=0., **physical)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            artifact = root / "results/C2_gap_s0/C2_gap.json"
            artifact.parent.mkdir(parents=True)
            artifact.write_text(json.dumps(dict(episodes=episodes, summary=summary)))
            artifact.with_suffix(".geometry.json").write_text(json.dumps({
                "task": "C2", "gpu_runtime_verified": True, "checkpoint": "/tmp/model.pt",
                "tiles": {"0,0": {"outer_radius": 1.2}}}))
            with patch.object(reference, "run_recorded"):
                reference.run_evaluation("C2", 0, Path("/tmp/model.pt"), Path("/tmp/python"), root, {}, ["C2"])
            report = json.loads((root / "C2/verified_C2.json").read_text())
            self.assertEqual(report["physical_obstacle_passage_rate"], 1.)
            self.assertTrue(report["required_obstacle_metrics_complete"])
            summary["physical_obstacle_passage_rate"] = .5
            artifact.write_text(json.dumps(dict(episodes=episodes, summary=summary)))
            with patch.object(reference, "run_recorded"), self.assertRaises(RuntimeError):
                reference.run_evaluation("C2", 0, Path("/tmp/model.pt"), Path("/tmp/python"), root, {}, ["C2"])


if __name__ == "__main__":
    unittest.main()
