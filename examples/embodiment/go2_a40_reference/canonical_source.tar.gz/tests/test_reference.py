"""Offline regression checks against the author sources; no simulator/robot is started."""
import ast
import argparse
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "a40"))
import reference as ref
import runtime_probe as probe


class ReferenceTests(unittest.TestCase):
    def test_parallel_training_identifies_own_run_not_another_seed(self):
        with tempfile.TemporaryDirectory() as tmp:
            bench = Path(tmp)
            argv = ref.source_recipe("A2", 0)
            log_root = bench / "logs/rsl_rl" / ref.flag(argv, "--experiment_name")
            own = log_root / ("2026-11-19_own_" + ref.flag(argv, "--run_name"))
            other = log_root / "2026-11-19_other_A2_omni_2048_s1"
            def execute(command, *_):
                if any(str(p).endswith("scripts/train.py") for p in command):
                    (own / "params").mkdir(parents=True)
                    other.mkdir()
                    for name in ("env.yaml", "agent.yaml"):
                        (own / "params" / name).write_text("test")
                    (own / "model_2999.pt").write_bytes(b"test")
            with patch.object(ref, "BENCH", bench), patch.object(ref, "source_recipe", return_value=argv), \
                 patch.object(ref, "run_recorded", side_effect=execute):
                session = bench / "session"
                (session / "A2").mkdir(parents=True)
                result = ref.run_training("A2", 0, Path("/tmp/python"), session, {})
            self.assertEqual(result.parent, own)

    def test_array_runs_only_five_seed_zero_specialists(self):
        text = (ROOT / "a40/a40_eight_array.sbatch").read_text()
        self.assertIn("#SBATCH --array=0-4%8", text)
        self.assertIn("#SBATCH --gres=gpu:1", text)
        self.assertIn("#SBATCH --cpus-per-task=4", text)
        self.assertNotIn("--distributed", text)
        tasks = list(ref.SOURCES)
        self.assertIn("TASK_SEED=0", text)
        self.assertNotIn("TASK_INDEX / 5", text)

    def test_copied_sources_and_all_fifteen_commands(self):
        ref.verify_source()

    def test_task_budgets_are_not_unified_2200(self):
        expected = {"A1": (2048, 3000), "A2": (2048, 1500), "B1": (2048, 3000),
                    "B2": (1024, 2200), "C2": (2048, 3000)}
        for task, (count, updates) in expected.items():
            for seed in (0, 1, 2):
                command = ref.source_recipe(task, seed)
                self.assertEqual(int(ref.flag(command, "--seed")), seed)
                self.assertEqual(int(ref.flag(command, "--num_envs")), count)
                self.assertEqual(int(ref.flag(command, "--max_iterations")), updates)
                self.assertNotIn("--resume", command)
                self.assertNotIn("--pretrained_checkpoint", command)

    def test_a1_uses_the_authors_legacy_variant(self):
        self.assertTrue(ref.flag(ref.source_recipe("A1", 0), "--task").endswith("-Legacy-v0"))
        self.assertNotIn("Legacy", ref.read_manifest()["tasks"]["A1"]["eval_gym_id"])

    def test_every_generated_option_is_accepted_by_original_parser(self):
        source = ast.parse((ref.BENCH / "scripts/train.py").read_text())
        nodes = []
        for node in source.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "parser" for t in node.targets):
                nodes.append(node)
            elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                function = node.value.func
                if isinstance(function, ast.Attribute) and isinstance(function.value, ast.Name) and function.value.id == "parser" and function.attr == "add_argument":
                    nodes.append(node)
        namespace = {"argparse": argparse}
        exec(compile(ast.Module(body=nodes, type_ignores=[]), "original_cli", "exec"), namespace)
        parser = namespace["parser"]
        parser.add_argument("--headless", action="store_true")
        for task in ref.SOURCES:
            for seed in (0, 1, 2):
                args, unknown = parser.parse_known_args(ref.source_recipe(task, seed))
                self.assertEqual(unknown, [])
                self.assertEqual(args.seed, seed)
                self.assertEqual(args.posture_reward_anneal, task == "B2")

    def test_posture_schedule_from_original_function(self):
        source = ast.parse((ref.BENCH / "scripts/train.py").read_text())
        function = next(n for n in source.body if isinstance(n, ast.FunctionDef) and n.name == "_lerp_weight")
        namespace = {}
        exec(compile(ast.Module(body=[function], type_ignores=[]), "original_schedule", "exec"), namespace)
        lerp = namespace["_lerp_weight"]
        self.assertEqual(lerp(0, 2200, 0, .35, -10, -3.5), -10)
        self.assertAlmostEqual(lerp(385, 2200, 0, .35, -10, -3.5), -6.75)
        self.assertEqual(lerp(770, 2200, 0, .35, -10, -3.5), -3.5)
        self.assertEqual(lerp(775, 2200, 0, .35, -5, -2), -2)
        command = ref.source_recipe("B2", 0)
        self.assertIn("--posture_reward_anneal", command)
        self.assertEqual(ref.flag(command, "--posture_anneal_end_frac"), "0.35")
        for task in ("A1", "A2", "B1", "C2"):
            self.assertIn("--no-posture_reward_anneal", ref.source_recipe(task, 0))

    def test_evaluation_retains_source_defaults_and_safe_paths(self):
        argv = ref.evaluation_argv("A1", 0, Path("/tmp/path with spaces/model.pt"), Path("/tmp/python"), Path("/tmp/eval"))
        self.assertEqual(ref.flag(argv, "--checkpoint"), "/tmp/path with spaces/model.pt")
        self.assertEqual(ref.flag(argv, "--num_envs"), "256")
        self.assertEqual(ref.flag(argv, "--num_episodes"), "1024")
        self.assertNotIn("--seed", argv)
        self.assertNotIn("env.seed=43", argv)
        self.assertFalse(any("enable_corruption" in arg or "curriculum" in arg for arg in argv))

    def test_plan_is_read_only_even_with_execute(self):
        with patch.object(sys, "argv", ["reference.py", "plan", "--execute"]), \
             patch.object(ref, "verify_source", return_value=ref.read_manifest()), \
             patch.object(ref.subprocess, "check_output", side_effect=AssertionError("hardware access")), \
             patch.object(ref, "run_training", side_effect=AssertionError("training started")), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            ref.main()
        self.assertEqual(len(json.loads(output.getvalue())["commands"]), 5)

    def test_local_asset_access_preserves_task_recipe(self):
        command = ref.training_argv("B2", 0, Path("/tmp/python"))
        self.assertEqual(ref.asset_argv(command, "cloud"), command)
        mirrored = ref.asset_argv(command, "mirror")
        self.assertEqual(mirrored[:-1], command)
        self.assertTrue(mirrored[-1].startswith("--kit_args=--/persistent/isaac/asset_root/cloud="))
        self.assertEqual(ref.flag(mirrored, "--seed"), "0")
        self.assertEqual(ref.flag(mirrored, "--num_envs"), "1024")
        self.assertEqual(ref.flag(mirrored, "--max_iterations"), "2200")

    def test_runtime_config_checker_rejects_frequency_and_seed_drift(self):
        actual = {"sim": {"dt": .01}, "seed": 42}
        errors = probe.compare(actual, {"sim.dt": .005, "seed": 0})
        self.assertEqual(len(errors), 2)
        self.assertEqual(probe.compare({"p": [1, 2]}, {"p": [1, 2]}), [])

    def test_corrupt_or_incomplete_eval_cannot_be_reported_as_success(self):
        for n, success_rate in ((2, 1.), (1024, 0.)):
            with self.subTest(n=n), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                path = root / "results/A2_omni_s0/A2_omni.json"
                path.parent.mkdir(parents=True)
                path.write_text(json.dumps({"episodes": [{"episode_success": True,
                    "termination_reason": "time_out"}] * n,
                    "summary": {"num_episodes": n, "success_rate": success_rate, "failure_rate": 0.}}))
                with patch.object(ref, "run_recorded"), self.assertRaises(RuntimeError):
                    ref.run_evaluation("A2", 0, Path("/tmp/model.pt"), Path("/tmp/python"), root, {}, ["A2"])

    def test_parallel_episode_overshoot_is_reported_with_actual_denominator(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "results/B2_stairs_s0/B2_stairs.json"
            path.parent.mkdir(parents=True)
            path.write_text(json.dumps({"episodes": [{"episode_success": True,
                "termination_reason": "time_out"}] * 1030,
                "summary": {"num_episodes": 1030, "success_rate": 1., "failure_rate": 0.}}))
            with patch.object(ref, "run_recorded"):
                ref.run_evaluation("B2", 0, Path("/tmp/model.pt"), Path("/tmp/python"), root, {}, ["B2"])
            report = json.loads((root / "B2/verified_B2.json").read_text())
            self.assertEqual(report["episodes"], 1030)
            self.assertIsNone(report["physical_obstacle_passage_rate"])
            self.assertEqual(report["physical_evaluation_status"], "pending_not_measured")
            self.assertFalse(report["required_obstacle_metrics_complete"])
            self.assertIsNone(report["joint_tracking_and_passage_success_rate"])


if __name__ == "__main__":
    unittest.main()
