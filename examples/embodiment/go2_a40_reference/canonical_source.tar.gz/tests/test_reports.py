"""Reporting must preserve pending measurements and reject inconsistent evidence."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "a40"))
import prepare_reports as report


class ReportingTests(unittest.TestCase):
    def test_all_five_static_configurations_match_source_recipe(self):
        audit = report.audit_configs()
        self.assertEqual(audit["status"], "passed")
        self.assertEqual(len(audit["checks"]), 125)
        self.assertFalse(audit["gpu_effective_configs_verified"])
        self.assertEqual(audit["tasks"]["B2"]["minibatch_samples"], 6144)
        self.assertEqual(audit["tasks"]["A2"]["requested_updates"], 1500)

    def test_unmeasured_results_are_null_for_all_ten_runs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config").mkdir()
            (root / "config/reference.json").write_text((ROOT / "config/reference.json").read_text())
            data = report.collect_results(root)
            self.assertEqual(len(data["records"]), 10)
            self.assertEqual(data["input_errors"], [])
            self.assertTrue(all(row["tracking_success_rate"] is None for row in data["records"]))
            self.assertTrue(all(row["episodes"] is None for row in data["records"]))

    def test_invalid_success_count_is_not_exported_as_a_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "config").mkdir()
            (root / "config/reference.json").write_text((ROOT / "config/reference.json").read_text())
            session = root / "outputs/train_s0_example"
            path = session / "A2/verified_A2.json"
            artifact = session / "results/A2.json"
            artifact.parent.mkdir(parents=True)
            path.parent.mkdir()
            episodes = [{"episode_success": True}] * 1024
            artifact.write_text(json.dumps(dict(episodes=episodes, summary=dict(success_rate=1.))))
            path.write_text(json.dumps(dict(artifact=str(artifact), episodes=1024, successes=0)))
            data = report.collect_results(root)
            self.assertEqual(len(data["input_errors"]), 1)
            self.assertFalse(any(row["status"] == "evaluated" for row in data["records"]))
            path.write_text(json.dumps(dict(artifact=str(artifact), episodes=1024, successes=1024)))
            data = report.collect_results(root)
            self.assertEqual(len(data["input_errors"]), 0)
            self.assertEqual(next(row for row in data["records"] if row["status"] == "evaluated")["tracking_success_rate"], 1.)

    def test_old_archive_or_another_workspace_cannot_be_mixed_into_report(self):
        with self.assertRaises(ValueError):
            report.local_artifact("/data1/qli736/old_mujoco/results.json", ROOT)
        self.assertEqual(report.local_artifact("/workspace/go2/outputs/example/results.json", ROOT),
                         ROOT / "outputs/example/results.json")


if __name__ == "__main__":
    unittest.main()
