#!/usr/bin/env bash
# Submit explicitly with a40/submit_reference.py; package preparation never submits.
# Account association and partition access verified by check_scheduler.py.
#SBATCH --job-name=go2_reference
#SBATCH --partition=i64m1tga40u
#SBATCH --account=root
#SBATCH --qos=i64m1tga40u
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-gpu=4
#SBATCH --mem=64G
#SBATCH --time=1-00:00:00
#SBATCH --output=slurm_%x_%j.out
#SBATCH --error=slurm_%x_%j.err
set -euo pipefail
TASK_ROOT="${GO2_PROJECT_ROOT:-${SLURM_SUBMIT_DIR:?Submit from the prepared project root}}"
cd "$TASK_ROOT"
echo "Job $SLURM_JOB_ID started at $(date -Is) on $(hostname)"
trap 'TASK_EXIT=$?; echo "Job $SLURM_JOB_ID finished at $(date -Is), exit=$TASK_EXIT"; exit "$TASK_EXIT"' EXIT
[[ -f config/reference.json ]] || { echo 'Incorrect project root' >&2; exit 2; }
[[ -s validation/prestart_status.json ]] || { echo 'Pre-start validation is missing' >&2; exit 2; }
python3 - <<'PY'
from pathlib import Path
import json
p=json.loads(Path('validation/prestart_status.json').read_text())
if p['status']!='non_simulation_preparation_complete':
    raise SystemExit('Pre-start validation is incomplete; inspect its logs before launch')
PY
TASK_MODE="${GO2_MODE:-suite}"
TASK_SEED="${GO2_SEED:-0}"
TASK_ASSETS="${GO2_ASSET_SOURCE:-cloud}"
case "$TASK_MODE" in
  suite) TASK_ARGS=(suite --seed "$TASK_SEED") ;;
  train) TASK_ARGS=(train --task "${GO2_TASK:-A2}" --seed "$TASK_SEED") ;;
  *) echo 'GO2_MODE must be suite or train' >&2; exit 2 ;;
esac
if [[ "${GO2_EXECUTE:-0}" != 1 ]]; then
  echo 'Plan only. Actual training requires explicit GO2_EXECUTE=1.'
  exec bash a40/hpc_environment.sh plan --seed "$TASK_SEED" --asset-source "$TASK_ASSETS"
fi
# The runtime checks A40 and performs config/smoke/full-count checks before formal training.
bash a40/hpc_environment.sh run "${TASK_ARGS[@]}" --asset-source "$TASK_ASSETS" --execute
