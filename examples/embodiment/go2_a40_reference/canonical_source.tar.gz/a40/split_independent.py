#!/usr/bin/env python3
"""Replace the two reviewed pending arrays with ten independent seed-0 jobs."""
import fcntl
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
OLD = ('14016570', '14016702')
TASKS = ('A1', 'A2', 'B1', 'B2', 'C2')


def slurm(*args):
    return subprocess.check_output(['bash', 'a40/slurm.sh', *args], cwd=ROOT,
                                   text=True, timeout=45).strip()


def main():
    records = ROOT / 'outputs/jobs'
    records.mkdir(parents=True, exist_ok=True)
    ledger = records / 'independent_seed0.json'
    with (records / 'submission.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if ledger.exists():
            raise SystemExit('Replacement already recorded; inspect ledger before retrying')
        rows = slurm('squeue', '--me', '-r', '-h', '-o', '%i|%j|%T|%Z')
        old_rows = [r for r in rows.splitlines() if r.split('|')[0].split('_')[0] in OLD]
        if len(old_rows) != 10 or any(r.split('|')[2] != 'PENDING' for r in old_rows):
            raise SystemExit('Expected exactly ten pending elements; inspect scheduler:\n' + rows)
        if any('|go2_ind_' in r for r in rows.splitlines()):
            raise SystemExit('Independent jobs already active')
        ready = json.loads((ROOT / 'validation/PRESTART_READY.json').read_text())
        assert not ready['errors'] and ready['training_pip_check_clean']
        for name in ('rlinf_cpu_checks.json', 'rlinf_dependency_overlay.json'):
            assert json.loads((ROOT / 'validation' / name).read_text())['status'] == 'passed'
        generated = []
        for lane, template in (('rsl', 'a40_eight_array.sbatch'), ('rlinf', 'a40_rlinf_array.sbatch')):
            source = (ROOT / 'a40' / template).read_text()
            for index, task in enumerate(TASKS):
                name = 'go2_ind_%s_%s' % (lane, task)
                lines = []
                for line in source.splitlines():
                    if line.startswith('#SBATCH --array='):
                        continue
                    if line.startswith('#SBATCH --job-name='):
                        line = '#SBATCH --job-name=' + name
                    elif line.startswith('#SBATCH --output='):
                        line = '#SBATCH --output=slurm_%x_%j.out'
                    elif line.startswith('#SBATCH --error='):
                        line = '#SBATCH --error=slurm_%x_%j.err'
                    elif line.startswith('TASK_INDEX='):
                        line = 'TASK_INDEX=%d' % index
                    line = line.replace('$SLURM_ARRAY_JOB_ID', '$SLURM_JOB_ID')
                    lines.append(line)
                path = ROOT / 'a40' / ('independent_%s_%s.sbatch' % (lane, task))
                path.write_text('\n'.join(lines) + '\n')
                subprocess.run(['bash', '-n', str(path)], check=True)
                generated.append({'learner': lane, 'task': task, 'seed': 0, 'name': name,
                                  'script': str(path.relative_to(ROOT)), 'gpus': 1})
        subprocess.run(['python3', 'a40/reference.py', 'check'], cwd=ROOT, check=True)
        record = {'created_unix': time.time(), 'old_arrays': OLD, 'old_queue': rows,
                  'status': 'prepared', 'jobs': []}
        def save():
            ledger.write_text(json.dumps(record, indent=2) + '\n')
        save()
        slurm('scancel', *OLD)
        remaining = slurm('squeue', '--me', '-r', '-h', '-o', '%i|%T')
        if any(r.split('|')[0].split('_')[0] in OLD for r in remaining.splitlines()):
            record['status'] = 'cancellation_not_confirmed'
            save()
            raise SystemExit('Old arrays still visible; no new jobs submitted')
        record['status'] = 'old_arrays_cancelled'
        save()
        for job in generated:
            # Save intent before sbatch: an interrupted response must be audited, not retried blindly.
            record['submission_in_progress'] = job
            save()
            response = slurm('sbatch', '--parsable', job['script'])
            job_id = response.split(';')[0]
            if not job_id.isdigit():
                raise RuntimeError('Unexpected sbatch response: ' + response)
            job['job_id'] = job_id
            record['jobs'].append(job)
            record.pop('submission_in_progress')
            save()
            print(json.dumps(job), flush=True)
        record['queue_after'] = slurm('squeue', '--me', '-r', '-o', '%.20i %.24j %.10T %.12b %.30R')
        record['status'] = 'ten_independent_jobs_submitted'
        save()
        print(record['queue_after'])


if __name__ == '__main__':
    main()

