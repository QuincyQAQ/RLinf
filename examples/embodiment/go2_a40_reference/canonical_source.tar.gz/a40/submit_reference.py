#!/usr/bin/env python3
"""Explicitly submit reviewed A40 jobs, refusing active duplicates."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def slurm(*args):
    return subprocess.run(["bash", str(ROOT / "a40/slurm.sh"), *args], cwd=ROOT,
                          text=True, capture_output=True, timeout=45, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eight", action="store_true", help="Five seed-0 specialists, one GPU each, concurrency ceiling eight")
    parser.add_argument("--rlinf", action="store_true", help="Add five independent native RLinf PPO jobs alongside the baseline")
    args = parser.parse_args()
    records = ROOT / "outputs/jobs"
    records.mkdir(parents=True, exist_ok=True)
    with (records / "submission.lock").open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        active = slurm("squeue", "--me", "-h", "-o", "%i|%j|%T|%Z").stdout
        names = ("go2_rlinf",) if args.rlinf else ("go2_reference", "go2_ref8")
        if any(any("|" + name + "|" in row for name in names) for row in active.splitlines()):
            raise SystemExit("A reference job is already active; inspect it before resubmitting.\n" + active)
        ready = json.loads((ROOT / "validation/PRESTART_READY.json").read_text())
        if ready["errors"] or not ready["training_pip_check_clean"]:
            raise SystemExit("Prestart checks have not passed")
        if args.rlinf:
            for file in ("rlinf_dependency_overlay.json", "rlinf_cpu_checks.json"):
                if json.loads((ROOT / "validation" / file).read_text())["status"] != "passed":
                    raise SystemExit("RLinf preflight has not passed: " + file)
        subprocess.run(["python3", "a40/reference.py", "check"], cwd=ROOT, check=True)
        subprocess.run(["bash", "-n", "a40/a40_job.sbatch", "a40/hpc_environment.sh"], cwd=ROOT, check=True)
        environment = dict(os.environ, GO2_MODE="train_each_array_element" if args.eight or args.rlinf else "suite", GO2_SEED="0",
                           GO2_ASSET_SOURCE="mirror", GO2_EXECUTE="1")
        template = "a40/a40_eight_array.sbatch" if args.eight else "a40/a40_job.sbatch"
        if args.rlinf:
            template = "a40/a40_rlinf_array.sbatch"
        subprocess.run(["bash", "-n", template], cwd=ROOT, check=True)
        command = ["bash", "a40/slurm.sh", "sbatch", "--parsable", "--export=ALL", template]
        submission = subprocess.run(command, cwd=ROOT, env=environment,
                                    text=True, capture_output=True, timeout=45)
        record = {"submitted_unix": time.time(), "command": command,
                  "cwd": str(ROOT), "returncode": submission.returncode,
                  "stdout": submission.stdout, "stderr": submission.stderr,
                  "settings": {k: environment[k] for k in
                               ("GO2_MODE", "GO2_SEED", "GO2_ASSET_SOURCE", "GO2_EXECUTE")},
                  "learner": "RLinf native PPO" if args.rlinf else "RSL-RL PPO",
                  "parallelism": {"max_concurrent_gpus": 5 if args.eight or args.rlinf else 1,
                                  "array_concurrency_ceiling": 8 if args.eight else (5 if args.rlinf else 1),
                                  "gpus_per_model": 1, "ddp": False,
                                  "task_seed_pairs": [{"array_index": seed * 5 + index,
                                                       "task": task, "seed": seed}
                                                      for seed in (0,)
                                                      for index, task in enumerate(("A1", "A2", "B1", "B2", "C2"))]
                                                      if args.eight or args.rlinf else None},
                  "training_recipes": "config/reference.json author_slurm_defaults",
                  "checks_before_training": ["A40/runtime config", "64-env 2-update PPO", "original-count 2-update PPO"],
                  "physical_passage_evaluator": "pending; not claimed completed by upstream tracking evaluation"}
        if submission.returncode:
            (records / ("failed_submission_%d.json" % time.time())).write_text(json.dumps(record, indent=2))
            raise SystemExit(submission.stderr)
        job_id = submission.stdout.strip().split(";")[0]
        if not job_id.isdigit():
            (records / "submission_response_needs_review.json").write_text(json.dumps(record, indent=2))
            raise SystemExit("Unexpected submission response; do not resubmit before checking squeue")
        prefix = "slurm_go2_ref8_%s_%%a" % job_id if args.eight else "slurm_go2_reference_%s" % job_id
        if args.rlinf:
            prefix = "slurm_go2_rlinf_%s_%%a" % job_id
        record.update(job_id=job_id, status="submitted", training_started_verified=False,
                      stdout_path=str(ROOT / (prefix + ".out")),
                      stderr_path=str(ROOT / (prefix + ".err")))
        (records / ("job_%s.json" % job_id)).write_text(json.dumps(record, indent=2))
        latest = "latest_rlinf_submission.json" if args.rlinf else "latest_submission.json"
        (records / latest).write_text(json.dumps(record, indent=2))
        details = slurm("scontrol", "show", "job", job_id).stdout
        (records / ("job_%s_initial_scontrol.txt" % job_id)).write_text(details)
        print(json.dumps(record, indent=2))
        print(details)


if __name__ == "__main__":
    main()
