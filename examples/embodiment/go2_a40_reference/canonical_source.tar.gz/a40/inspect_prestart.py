#!/usr/bin/env python3
"""CPU-only inspection of bundled USD and asset settings. Does not start Kit."""
import importlib.metadata as metadata
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
report = {"simulation_started": False, "gpu_used": False, "usd": {}, "asset_settings": [], "packages": {}}
try:
    from pxr import Sdf, Usd
    layer = Sdf.Layer.CreateAnonymous("prestart.usda")
    layer.ImportFromString('#usda 1.0\ndef Xform "CPUOnly" {}\n')
    report["usd"] = {"version": list(Usd.GetVersion()), "sdf_origin": Sdf.__file__,
                     "layer_parse_ok": bool(layer.GetPrimAtPath("/CPUOnly"))}
except Exception as exc:
    report["usd"]["error"] = f"{type(exc).__name__}: {exc}"
for parent in [Path("/isaac-sim/apps"), Path("/isaac-sim/exts/isaacsim.asset.browser/config")]:
    if parent.exists():
        for path in parent.rglob("*"):
            if path.is_file() and path.suffix in (".kit", ".toml"):
                for line in path.read_text(errors="replace").splitlines():
                    if "asset_root" in line or re.search(r"https?://[^\s\"]*/Assets/Isaac", line):
                        report["asset_settings"].append({"file": str(path), "line": line})
for name in ["fastapi", "starlette", "lxml", "msal", "pin-pink", "nvidia-srl-base", "nvidia-srl-usd"]:
    try:
        dist = metadata.distribution(name)
        report["packages"][name] = {"version": dist.version, "requires": dist.requires}
    except metadata.PackageNotFoundError:
        report["packages"][name] = None
(ROOT / "validation/prestart_inventory.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
