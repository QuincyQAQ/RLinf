"""Validate RSL->RLinf midpoint weight compatibility without initializing CUDA."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1]
for path in [ROOT/'RLinf',ROOT/'.rlinf_overlay']:
    sys.path.insert(0,str(path))
import torch
from rlinf.models.embodiment.go2_policy.go2_policy import Go2Policy
checkpoint=ROOT/'benchmark/logs/rsl_rl/unitree_go2_a2_baseline_2048_seeds/2026-11-19_20-27-02_A2_omni_2048_s0/model_750.pt'
d=torch.load(checkpoint,map_location='cpu',weights_only=False)
model=Go2Policy(obs_dim=235,critic_obs_dim=235,obs_normalization=False)
model.load_state_dict(d['model_state_dict'],strict=True)
assert all(torch.isfinite(v).all() for v in model.state_dict().values())
assert (model.std>0).all()
x=torch.zeros(4,235)
assert torch.isfinite(model.actor(x)).all() and model.actor(x).shape==(4,12)
assert not torch.cuda.is_initialized()
print(json.dumps(dict(status='passed',source_iter=d.get('iter'),strict_load=True,cuda_initialized=False)))
