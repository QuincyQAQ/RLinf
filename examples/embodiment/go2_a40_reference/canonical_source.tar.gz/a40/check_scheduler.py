#!/usr/bin/env python3
"""Read scheduler/association metadata; never submit or allocate a job."""
import getpass
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    user = getpass.getuser()
    calls = {
        "version": ["sinfo", "--version"],
        "partition": ["scontrol", "show", "partition", "i64m1tga40u"],
        "user": ["sacctmgr", "-nP", "show", "user", "where", "name=" + user,
                 "format=User,DefaultAccount"],
        "association": ["sacctmgr", "-nP", "show", "assoc", "where", "user=" + user,
                        "format=Cluster,Account,User,Partition,QOS,DefaultQOS,MaxTRES,GrpTRES,MaxJobs,MaxSubmitJobs"],
        "qos": ["sacctmgr", "-nP", "show", "qos", "where", "name=i64m1tga40u",
                "format=Name,MaxWall,MaxTRESPU,MaxJobsPU,MaxSubmitPU"],
        "own_jobs": ["squeue", "--me", "-h", "-o", "%i|%P|%j|%T|%b"],
    }
    results = {}
    for name, command in calls.items():
        start = time.monotonic()
        p = subprocess.run(["bash", str(ROOT / "a40/slurm.sh"), *command],
                           text=True, capture_output=True, timeout=15)
        results[name] = {"command": command, "returncode": p.returncode,
                         "stdout": p.stdout, "stderr": p.stderr,
                         "seconds": time.monotonic() - start}
        if p.returncode:
            raise RuntimeError(name + ": " + p.stderr)
    part = results["partition"]["stdout"]
    associations = [row.split("|") for row in results["association"]["stdout"].splitlines()]
    matched = [row for row in associations if len(row) >= 5 and row[2] == user
               and "i64m1tga40u" in row[4].split(",") and row[3] in ("", "i64m1tga40u")]
    access = bool(matched) and all(s in part for s in
        ["AllowGroups=ALL", "AllowAccounts=ALL", "AllowQos=ALL", "State=UP"])
    report = {"status": "passed" if access else "needs_review", "queried_unix": time.time(),
              "user": user, "client": "/opt/slurm/bin", "results": results,
              "root_cause": "Non-login SSH used Ubuntu system clients in /usr/bin instead of site Slurm 23.02",
              "partition_verified": access, "account_verified": bool(matched),
              "account": matched[0][1] if matched else None, "qos": "i64m1tga40u",
              "account_permission_metadata_verified": access,
              "account_allocation_verified": False, "gpu_job_submitted": False,
              "note": "Association and access rules verified; no submission test, allocated GPU, billing balance or guaranteed scheduling time claimed."}
    (ROOT / "validation/cluster_scheduler_query.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    if not access:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
