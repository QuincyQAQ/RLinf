#!/usr/bin/env bash
#SBATCH --job-name=go2_C2_recovery_gate
#SBATCH --partition=debug
#SBATCH --account=root
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=00:30:00
#SBATCH --output=slurm_%x_%j.out
#SBATCH --error=slurm_%x_%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
bash a40/hpc_environment.sh run-rlinf-probe --task C2 --evaluate "$@"
