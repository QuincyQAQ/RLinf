"""One prespecified new evaluation seed for all three frozen A1 checkpoints."""
import argparse
import hashlib
import json
import os
import traceback
from reference import ROOT
from b2_continuation import evaluate,validate,write
p=argparse.ArgumentParser();p.add_argument('--python',required=True);a=p.parse_args()
assert os.environ.get('SLURM_JOB_ID')
source=ROOT/'outputs/fullppo_huber_A1_14029742'
original=json.loads((source/'result.json').read_text())
assert original['status']=='verified'
models={'baseline':original['protocol']['source'],
        'rlinf_huber':str(source/'rlinf_huber/training/policy.pt'),
        'rsl_control':json.loads((source/'rsl_control/training/validation.json').read_text())['checkpoint']}
root=ROOT/'outputs'/('a1_confirmatory_'+os.environ['SLURM_JOB_ID']);root.mkdir()
seed=45678
protocol=dict(task='A1',training_seed=0,new_evaluation_seed=seed,all_lanes_same_seed=True,
              episodes_per_lane_minimum=1024,models=models,original_result=str(source/'result.json'),
              selection='all new results retained; original results retained; no winner-dependent reruns',
              scope='evaluation-only; no training/config/checkpoint tuning')
write(root/'protocol.json',protocol)
def digest(path):return hashlib.sha256(__import__('pathlib').Path(path).read_bytes()).hexdigest()
try:
    hashes={lane:digest(path) for lane,path in models.items()}
    fresh={}
    for lane,path in models.items():
        validate(__import__('pathlib').Path(path))
        write(root/'progress.json',dict(stage='evaluation',lane=lane,seed=seed))
        fresh[lane]=evaluate(a.python,__import__('pathlib').Path(path),root/lane,seed,'A1')
        write(root/'partial_results.json',fresh)
    pooled={}
    for lane,row in fresh.items():
        rows=list(original['results'][lane].values())+[row]
        n=sum(r['num_episodes'] for r in rows)
        successes=sum(round(r['num_episodes']*r['success_rate']) for r in rows)
        pooled[lane]=dict(episodes=n,successes=successes,tracking_rate=successes/n,
                         mean_lin_vel_error=sum(r['mean_lin_vel_error']*r['num_episodes'] for r in rows)/n,
                         mean_ang_vel_error=sum(r['mean_ang_vel_error']*r['num_episodes'] for r in rows)/n)
    assert hashes=={lane:digest(path) for lane,path in models.items()},'Checkpoint changed during evaluation'
    write(root/'result.json',dict(status='verified',protocol=protocol,sha256=hashes,
         new_seed_results=fresh,pooled_original_and_new=pooled,
         caveat='one training seed, near-ceiling tracking metric; no guaranteed RLinf ranking'))
    write(root/'progress.json',dict(stage='completed'))
except BaseException as exc:
    write(root/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc()));raise
