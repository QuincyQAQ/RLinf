#!/usr/bin/env bash
# Login-node preparation only. No Kit, simulator, GPU allocation, or training.
set -euo pipefail
TASK_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$TASK_ROOT"
trap 'python3 -c '\''import json,time;from pathlib import Path;Path("validation/prestart_status.json").write_text(json.dumps({"status":"failed","unix":time.time(),"log":"validation/complete_prestart.log","simulation_started":False,"training_started":False},indent=2))'\''' ERR
python3 -c 'import json,time;from pathlib import Path;Path("validation/prestart_status.json").write_text(json.dumps({"status":"preparing","unix":time.time(),"simulation_started":False,"training_started":False},indent=2))'
TASK_WAIT_DEADLINE=$((SECONDS + 1800))
while [[ ! -s validation/unpacked_container.json ]]; do
  [[ $SECONDS -lt $TASK_WAIT_DEADLINE ]] || { echo 'Container extraction timeout' >&2; false; }
  echo 'Waiting for reusable official container extraction...'
  sleep 10
done
if [[ ! -s validation/extra_overlay_ready.json ]]; then
  TASK_EXTRA_REQUIREMENTS=config/prestart-extra.in
  if [[ -f config/prestart-extra.lock.txt ]]; then TASK_EXTRA_REQUIREMENTS=config/prestart-extra.lock.txt; fi
  bash a40/hpc_environment.sh python-cpu -m pip install --upgrade --target /workspace/go2/.extra_overlay \
    --constraint /workspace/go2/config/constraints.txt --requirement "/workspace/go2/$TASK_EXTRA_REQUIREMENTS" \
    --report /workspace/go2/validation/extra_overlay_install_report.json
  bash a40/hpc_environment.sh python-cpu a40/validate_extra_overlay.py
fi
if [[ ! -d .asset_tools/pxr || ! -d .asset_tools/usd_core.libs ]]; then
  bash a40/hpc_environment.sh python-cpu -m pip install --no-deps --target /workspace/go2/.asset_tools 'usd-core==25.2.post1'
fi
bash a40/prepare_usd_isolation.sh
bash a40/hpc_environment.sh python-cpu a40/prepare_assets.py
bash a40/hpc_environment.sh python-cpu a40/finalize_cpu_environment.py
python3 - <<'PY'
from pathlib import Path
import json,time
root=Path.cwd()
assets=json.loads((root/'validation/asset_mirror.json').read_text())
core=json.loads((root/'validation/HPC_SETUP_STATUS.json').read_text())
assert assets['status']=='passed' and core['core_package_verification']=='passed'
(root/'validation/prestart_status.json').write_text(json.dumps({
    'status':'non_simulation_preparation_complete','finished_unix':time.time(),
    'asset_files':assets['file_count'],'asset_bytes':assets['total_bytes'],
    'core_status':core['status'],'unresolved_dependency_issues':core['unresolved_training_dependency_issues'],
    'simulation_started':False,'training_started':False,'gpu_job_submitted':False,
    'remaining_requires_compute_node':['NVIDIA driver and Vulkan','original environment creation and asset resolution',
       '64-env PPO smoke','full-count PPO capacity'],
},indent=2))
PY
