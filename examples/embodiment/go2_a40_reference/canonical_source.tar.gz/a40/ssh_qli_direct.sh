#!/usr/bin/env bash
# Run on this local laptop: only this SSH connection bypasses the Clash TUN.
set -euo pipefail
TASK_SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
printf -v TASK_PROXY_COMMAND 'python3 %q --interface wlp3s0 --dns 10.90.63.2 %%h %%p' "$TASK_SCRIPT_DIR/ssh_direct.py"
exec ssh -o "ProxyCommand=$TASK_PROXY_COMMAND" -o ConnectTimeout=15 qli "$@"
