"""Resubmit only the eight failed seed-zero jobs, gated on a successful compute smoke."""
import argparse
import fcntl
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]
SLURM=Path('/opt/slurm/bin')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--smoke-job',type=int,required=True)
    args=parser.parse_args()
    directory=ROOT/'outputs/jobs';directory.mkdir(parents=True,exist_ok=True)
    lock=(directory/'container_recovery.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    path=directory/'container_recovery_seed0.json'
    manifest=json.loads(path.read_text()) if path.exists() else dict(smoke_job=args.smoke_job,created=time.time(),jobs=[])
    if manifest['smoke_job']!=args.smoke_job:raise RuntimeError('Existing recovery uses another smoke job; inspect before replacing')
    old=[14019295,14019296,14019297,14019298,14019300,14019301,14019302,14019303]
    scripts=[f'independent_{method}_{task}.sbatch' for method in ['rsl','rlinf'] for task in ['A1','A2','B1','B2']]
    for job,script in zip(old,scripts):
        if any(x['old_job']==job for x in manifest['jobs']):continue
        state=subprocess.check_output([str(SLURM/'sacct'),'-n','-X','-j',str(job),'--format=State','-P'],text=True).strip()
        if state!='FAILED':raise RuntimeError(f'Refusing duplicate: old job {job} state={state}')
        command=[str(SLURM/'sbatch'),'--parsable',f'--dependency=afterok:{args.smoke_job}',str(ROOT/'a40'/script)]
        result=subprocess.check_output(command,cwd=ROOT,text=True).strip()
        new=int(result.split(';')[0]);manifest['jobs'].append(dict(old_job=job,new_job=new,script=script,submitted=time.time()))
        temp=path.with_suffix('.tmp');temp.write_text(json.dumps(manifest,indent=2));temp.replace(path)
        print(f'{job} -> {new} {script}',flush=True)


if __name__=='__main__':main()
