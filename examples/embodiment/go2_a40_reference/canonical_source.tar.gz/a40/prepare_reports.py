#!/usr/bin/env python3
"""Produce a config comparison and evidence-based experiment reports without simulation."""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
from pathlib import Path

from reference import ROOT, SOURCES, flag, source_recipe, verify_source
from rlinf_reference import make_config
from runtime_probe import nested


LANES = {"rsl": "RSL-RL PPO", "rlinf": "RLinf PPO"}
MAPPING = [
    ("rollout steps/env", "num_steps_per_env", "env.train.max_steps_per_rollout_epoch"),
    ("actor observation normalization", "policy.actor_obs_normalization", "actor.model.obs_normalization"),
    ("critic observation normalization", "policy.critic_obs_normalization", "actor.model.obs_normalization"),
    ("PPO epochs", "algorithm.num_learning_epochs", "algorithm.update_epoch"),
    ("learning rate", "algorithm.learning_rate", "actor.optim.lr"),
    ("critic learning rate", "algorithm.learning_rate", "actor.optim.value_lr"),
    ("gamma", "algorithm.gamma", "algorithm.gamma"),
    ("GAE lambda", "algorithm.lam", "algorithm.gae_lambda"),
    ("positive policy clip", "algorithm.clip_param", "algorithm.clip_ratio_high"),
    ("negative policy clip", "algorithm.clip_param", "algorithm.clip_ratio_low"),
    ("value clip", "algorithm.clip_param", "algorithm.value_clip"),
    ("entropy coefficient", "algorithm.entropy_coef", "algorithm.entropy_bonus"),
    ("target KL", "algorithm.desired_kl", "algorithm.desired_kl"),
    ("max gradient norm", "algorithm.max_grad_norm", "actor.optim.clip_grad"),
    ("checkpoint interval", "save_interval", "runner.save_interval"),
]


def audit_configs(root=ROOT):
    manifest = verify_source()
    rows, tasks, mismatches = [], {}, []
    expected = manifest["agent_expectations"]
    for task, recipe in manifest["tasks"].items():
        cfg = make_config(task, root / "outputs/REPORT_PLAN" / task)
        for title, source_key, target_key in MAPPING:
            baseline, native = expected[source_key], nested(cfg, target_key)
            row = dict(task=task, field=title, reference=baseline, rlinf=native,
                       reference_key=source_key, rlinf_key=target_key, equal=baseline == native)
            rows.append(row)
            if not row["equal"]:
                mismatches.append(row)
        argv = source_recipe(task, 0)
        count, updates = int(flag(argv, "--num_envs")), int(flag(argv, "--max_iterations"))
        rollout = count * manifest["sampling"]["rollout_steps_per_env"]
        minibatch = rollout // expected["algorithm.num_mini_batches"]
        extra = {"environment count": (count, cfg["env"]["train"]["total_num_envs"]),
                 "training seed": (int(flag(argv, "--seed")), cfg["actor"]["seed"]),
                 "environment seed": (0, cfg["env"]["train"]["seed"]),
                 "update budget": (updates, cfg["runner"]["max_steps"]),
                 "PPO minibatch samples": (minibatch, cfg["actor"]["global_batch_size"]),
                 "PPO microbatch samples": (minibatch, cfg["actor"]["micro_batch_size"]),
                 "observation dimension": (235, cfg["actor"]["model"]["obs_dim"]),
                 "critic dimension": (235, cfg["actor"]["model"]["critic_obs_dim"]),
                 "action dimension": (12, cfg["actor"]["model"]["action_dim"]),
                 "scratch initialization": (None, cfg["actor"]["model"]["initial_checkpoint"])}
        for title, (baseline, native) in extra.items():
            row = dict(task=task, field=title, reference=baseline, rlinf=native, equal=baseline == native)
            rows.append(row)
            if not row["equal"]:
                mismatches.append(row)
        tasks[task] = dict(num_envs=count, requested_updates=updates, rollout_transitions=rollout,
                           minibatch_samples=minibatch, total_transitions=rollout * updates,
                           optimizer_steps_per_rollout=expected["algorithm.num_learning_epochs"] * expected["algorithm.num_mini_batches"],
                           original_script=recipe["source"])
    return dict(status="passed" if not mismatches else "mismatch", checked_at=dt.datetime.now(dt.timezone.utc).isoformat(),
                comparison="original RSL-RL PPO versus native RLinf PPO, both from scratch",
                checks=rows, mismatches=mismatches, tasks=tasks,
                shared_environment_contract=manifest["common_env_expectations"],
                b2_schedule=manifest["b2_schedule"], gpu_effective_configs_verified=False,
                limits=["Static CLI/config comparison; A40 effective-config and simulation probes remain required.",
                        "Learner implementations, minibatch order, RNG consumption and timeout/bootstrap implementation differ.",
                        "Identical seed numbers do not imply identical trajectories or initialized weights across frameworks.",
                        "Both groups use PPO. This comparison measures framework implementations, not PPO versus no PPO.",
                        "Published historical checkpoint configurations and the author's binary container are incomplete."])


def write_comparison(output):
    report = audit_configs()
    output.mkdir(parents=True, exist_ok=True)
    (output / "CONFIG_COMPARISON.json").write_text(json.dumps(report, indent=2))
    lines = ["# 两组训练配置对照", "", "这是原 RSL-RL PPO 与 RLinf PPO 的框架对照，两组均从零使用 PPO；不能称作使用 PPO 与未使用 PPO 的比较。", "",
             f"静态检查：**{report['status']}**，共 {len(report['checks'])} 项逐任务字段核对。真实 A40 生效配置仍须由作业内探针验证。", "",
             "| 任务 | 两组环境数 | 两组更新预算 | 每轮交互 | minibatch | 每轮优化步 | 总交互预算 |", "|---|---:|---:|---:|---:|---:|---:|"]
    for task, row in report["tasks"].items():
        lines.append(f"| {task} | {row['num_envs']} | {row['requested_updates']} | {row['rollout_transitions']:,} | {row['minibatch_samples']:,} | {row['optimizer_steps_per_rollout']} | {row['total_transitions']:,} |")
    lines += ["", "原专项脚本路径、逐字段 key/value 和检查结果在同名 JSON；所有训练 seed 为 0，seed 1/2 未安排。每模型一张 A40、4 CPU、64 GiB，五项独立训练；每组最多五项并行，不做多卡 DDP。", "",
              "| 共同项 | 设置 |", "|---|---|",
              "| 模拟器与任务 | 同一份原 Isaac Lab v2.3.2 / Isaac Sim 5.1 PhysX，原任务与奖励源文件保留 |",
              "| 采样 | 物理 200 Hz、控制 50 Hz、每环境 24 步、20 秒回合、指令每 10 秒重采样 |",
              "| 观测 / 动作 | 235 维观测、12 维关节位置动作、scale 0.25、默认关节位置偏置 |",
              "| 网络 | ELU，actor/critic 512→256→128，初始动作 std 1，观测归一化关闭 |",
              "| PPO | 5 epochs、4 minibatches、clip 0.2、entropy 0.01、value coefficient 1 |",
              "| 优化 | 初始学习率 0.001，KL 目标 0.01 自适应，gamma 0.99、lambda 0.95、梯度裁剪 1 |",
              "| RLinf loss | actor_critic、clipped MSE value loss；关闭额外 dual clipping |",
              "| B2 调度 | 前 35% 预算，高度惩罚 −10→−3.5、姿态惩罚 −5→−2，每 25 次更新调整 |",
              "| 评测 | 256 环境、至少 1024 回合，原成功率；B2/C2 同回合追加物理通过率和交集 |", "",
              "## 需要单独记录的差异", "",
              "RSL-RL 使用原 OnPolicyRunner；RLinf 使用原生 runner、actor/env/rollout workers 和 actor_critic loss。网络与显式数值参数对齐，不代表随机数消耗、batch shuffle、初始权重、GAE/timeout bootstrap 或优化器执行逐位一致。RLinf 的扩展 loss/KL 功能来自本项目分支，不能误称为未改动的上游默认训练。", "",
              "RSL-RL 的 B2 分块 learn 调用可能重复 checkpoint 编号；报告把请求更新预算、checkpoint 标签和已证实的更新数分开。PPO global step 不能换算成 SFT epoch。", "",
              "公开原脚本默认参数与历史发表 checkpoint 配置不同，不能据此保证复现作者成功率。详见 ../docs/REFERENCE_AUDIT.md 和 ../docs/EXPERIMENT_SETTINGS_RECHECK_20261119.md。", ""]
    (output / "CONFIG_COMPARISON.md").write_text("\n".join(lines))
    if report["mismatches"]:
        raise RuntimeError("Configuration differences found; inspect CONFIG_COMPARISON.json")
    return report


def local_artifact(path, root):
    path = Path(path)
    if str(path).startswith("/workspace/go2/"):
        path = root / path.relative_to("/workspace/go2")
    elif not path.is_absolute():
        path = root / path
    if not path.resolve().is_relative_to((root / "outputs").resolve()):
        raise ValueError("Report input must belong to this workspace's outputs")
    return path


def collect_results(root=ROOT):
    """Read verified main-task evaluations only; missing results remain null."""
    manifest = json.loads((root / "config/reference.json").read_text())
    rows, errors, observed = [], [], set()
    for verified in sorted((root / "outputs").glob("*/[ABC]*/verified_*.json")):
        task = verified.parent.name
        if task not in SOURCES or verified.stem != "verified_" + task:
            continue
        session = verified.parent.parent
        lane = "rlinf" if session.name.startswith("rlinf_") else "rsl" if session.name.startswith("train_s0_") else None
        if lane is None:
            continue
        try:
            data = json.loads(verified.read_text())
            artifact = local_artifact(data["artifact"], root)
            payload = json.loads(artifact.read_text())
            episodes = payload["episodes"]
            n = len(episodes)
            successes = sum(bool(e["episode_success"]) for e in episodes)
            if n < 1024 or data["episodes"] != n or data["successes"] != successes:
                raise ValueError("Invalid episode count or success count")
            if abs(payload["summary"]["success_rate"] - successes / n) > 1e-10:
                raise ValueError("Tracking summary differs from actual episodes")
            if data.get("physical_evaluation_status") == "measured":
                from passage_metrics import summarize_passage
                physical = summarize_passage(episodes)
                for key, value in physical.items():
                    if data.get(key) != value:
                        raise ValueError("Physical verified summary differs from actual episodes")
            launch = session / task / "training/launch.json" if lane == "rsl" else session / "training/launch.json"
            launch_data = json.loads(launch.read_text()) if launch.is_file() else {}
            eval_launch = session / task / f"eval_{task}/launch.json"
            eval_data = json.loads(eval_launch.read_text()) if eval_launch.is_file() else {}
            eval_argv = eval_data.get("argv", [])
            checkpoint = flag(eval_argv, "--checkpoint") if "--checkpoint" in eval_argv else None
            elapsed = None
            if launch_data.get("start") and launch_data.get("end"):
                fmt = "%Y%m%d_%H%M%S_%f"
                elapsed = (dt.datetime.strptime(launch_data["end"], fmt) - dt.datetime.strptime(launch_data["start"], fmt)).total_seconds()
            rows.append(dict(task=task, learner=LANES[lane], seed=0, status="evaluated",
                             session=session.name, requested_updates=manifest["tasks"][task]["max_iterations"],
                             confirmed_updates=None, checkpoint_label=Path(checkpoint).name if checkpoint else None,
                             checkpoint_path=checkpoint,
                             episodes=n, tracking_successes=successes, tracking_success_rate=successes / n,
                             physical_passage_rate=data.get("physical_obstacle_passage_rate"),
                             joint_success_rate=data.get("joint_tracking_and_passage_success_rate"),
                             physical_status=data.get("physical_evaluation_status", "not_recorded"),
                             mean_lin_velocity_error=payload["summary"].get("mean_lin_vel_error"),
                             mean_yaw_velocity_error=payload["summary"].get("mean_ang_vel_error"),
                             failure_rate=payload["summary"].get("failure_rate"),
                             training_seconds=elapsed, verified_artifact=str(verified), raw_artifact=str(artifact)))
            observed.add((task, lane))
        except (OSError, KeyError, TypeError, ValueError) as exc:
            errors.append(dict(path=str(verified), error=str(exc)))
    for task in SOURCES:
        for lane, learner in LANES.items():
            if (task, lane) in observed:
                continue
            rows.append(dict(task=task, learner=learner, seed=0, status="awaiting_verified_evaluation",
                requested_updates=manifest["tasks"][task]["max_iterations"], confirmed_updates=None,
                episodes=None, tracking_successes=None, tracking_success_rate=None,
                physical_passage_rate=None, joint_success_rate=None,
                physical_status="pending" if task in {"B2", "C2"} else "not_applicable",
                mean_lin_velocity_error=None, mean_yaw_velocity_error=None, failure_rate=None,
                training_seconds=None, verified_artifact=None))
    return dict(generated_at=dt.datetime.now(dt.timezone.utc).isoformat(), records=rows, input_errors=errors,
                note="Missing results are null, not zero; one training seed does not support across-seed claims.")


def write_results(output, root=ROOT):
    report = collect_results(root)
    output.mkdir(parents=True, exist_ok=True)
    (output / "RESULTS.json").write_text(json.dumps(report, indent=2))
    columns = list(dict.fromkeys(key for row in report["records"] for key in row))
    with (output / "RESULTS.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(report["records"])
    lines = ["# Go2 两组实验结果", "", "无已验证结果的单元格保留待测，不能把待测当作 0% 或训练失败。此表仅汇集主任务评测；不是完整 5×5 矩阵。", "",
             "| 任务 | 训练框架 | seed | 请求更新数 | 评测回合数 | 原跟踪成功率 | 物理通过率 | 交集成功率 | 状态 |", "|---|---|---:|---:|---:|---:|---:|---:|---|"]
    percent = lambda value: "待测" if value is None else f"{100 * value:.2f}%"
    for row in report["records"]:
        lines.append(f"| {row['task']} | {row['learner']} | {row['seed']} | {row['requested_updates']} | {row['episodes'] if row['episodes'] is not None else '待测'} | {percent(row['tracking_success_rate'])} | {percent(row['physical_passage_rate']) if row['physical_status'] != 'not_applicable' else '不适用'} | {percent(row['joint_success_rate']) if row['physical_status'] != 'not_applicable' else '不适用'} | {row['status']} |")
    lines += ["", "CSV/JSON 另含速度误差、失败率、已记录的训练耗时及原始证据路径。confirmed_updates 缺少可靠计数时为 null，不从 RSL-RL B2 文件名推断。RLinf 训练日志没有显式起止时间时，耗时也不以文件修改时间代替。", "",
              "曲线必须来自多个独立评测 checkpoint 的真实记录，不能从最终值插值；单 seed 的结果不提供训练种子间方差。两组都使用 PPO，只能比较两种框架实现。", "",
              f"输入错误数：{len(report['input_errors'])}。错误记录保留在 RESULTS.json，不把损坏数据当成有效结果。", ""]
    (output / "RESULTS.md").write_text("\n".join(lines))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "reports")
    args = parser.parse_args()
    audit = write_comparison(args.output)
    results = write_results(args.output)
    print(json.dumps(dict(config_status=audit["status"], field_checks=len(audit["checks"]),
                          result_records=len(results["records"]), input_errors=len(results["input_errors"]),
                          output=str(args.output)), indent=2))
    if results["input_errors"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
