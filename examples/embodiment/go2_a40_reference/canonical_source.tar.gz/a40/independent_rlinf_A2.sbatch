#!/usr/bin/env bash
# Native RLinf PPO on the same five Isaac Lab tasks, seed zero only.
#SBATCH --job-name=go2_ind_rlinf_A2
#SBATCH --partition=emergency_gpua40
#SBATCH --account=root
#SBATCH --qos=emergency_gpua40
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=1-00:00:00
#SBATCH --output=slurm_%x_%j.out
#SBATCH --error=slurm_%x_%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?Submit from the prepared project root}"
TASK_NAMES=(A1 A2 B1 B2 C2)
TASK_INDEX=1
[[ "$TASK_INDEX" -ge 0 && "$TASK_INDEX" -lt 5 ]] || exit 2
echo "RLinf job $SLURM_JOB_ID: ${TASK_NAMES[$TASK_INDEX]} seed 0 started $(date -Is) on $(hostname)"
trap 'TASK_EXIT=$?; echo "RLinf job finished $(date -Is), exit=$TASK_EXIT"; exit "$TASK_EXIT"' EXIT
python3 - <<'PY'
from pathlib import Path
import json
for f in ['rlinf_cpu_checks.json','rlinf_dependency_overlay.json']:
    j=json.loads((Path('validation')/f).read_text())
    assert j['status']=='passed',f
PY
bash a40/hpc_environment.sh run-rlinf --task "${TASK_NAMES[$TASK_INDEX]}"
