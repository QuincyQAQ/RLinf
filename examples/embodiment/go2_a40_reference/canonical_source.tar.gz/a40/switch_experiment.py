#!/usr/bin/env python3
"""Paired A2 midpoint continuation: same weights, fresh optimizers, equal samples."""
import argparse,json,os,hashlib,subprocess
from pathlib import Path
from reference import ROOT,source_recipe,stamp,verify_source,evaluation_argv,SHORT
from rlinf_reference import run_phase


def checked(command,directory):
    directory.mkdir(parents=True,exist_ok=True)
    with (directory/'console.log').open('w') as log:
        subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True)


def evaluate(checkpoint,session,python,label):
    out=session/label
    cmd=evaluation_argv('A2',0,checkpoint,python,out)
    cmd[1]=str(ROOT/'a40/evaluate_switch.py')
    checked(cmd,out)
    artifact=out/'A2_omni_s0/A2_omni.json'
    d=json.loads(artifact.read_text());episodes=d['episodes'];summary=d['summary']
    rate=sum(bool(e['episode_success']) for e in episodes)/len(episodes)
    if len(episodes)<1024 or summary['num_episodes']!=len(episodes) or abs(rate-summary['success_rate'])>1e-10:
        raise RuntimeError('Evaluation consistency failed')
    return dict(summary,explicit_environment_eval_seed=12345,artifact=str(artifact))


def main():
    p=argparse.ArgumentParser();p.add_argument('--lane',choices=['rsl','rlinf'],required=True)
    p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--python',type=Path,required=True)
    a=p.parse_args();verify_source()
    if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Requires allocated compute job')
    import torch
    from rlinf.models.embodiment.go2_policy.go2_policy import Go2Policy
    state=torch.load(a.checkpoint,map_location='cpu',weights_only=False)['model_state_dict']
    policy=Go2Policy(obs_dim=235,critic_obs_dim=235,obs_normalization=False)
    policy.load_state_dict(state,strict=True)
    if not all(torch.isfinite(v).all() for v in state.values()):raise RuntimeError('Non-finite initial state')
    session=ROOT/'outputs'/('switch_A2_mid_'+a.lane+'_'+stamp());session.mkdir(parents=True)
    receipt=dict(lane=a.lane,source=str(a.checkpoint),sha256=hashlib.sha256(a.checkpoint.read_bytes()).hexdigest(),
        source_iter=torch.load(a.checkpoint,map_location='cpu',weights_only=False).get('iter'),
        additional_updates=750,num_envs=2048,steps_per_rollout=24,additional_samples=36864000,
        training_seed=0,evaluation_seed=12345,optimizer='fresh in both lanes',environment='fresh in both lanes',
        caveat='midpoint experiment; plateau not established; framework details still differ')
    (session/'protocol.json').write_text(json.dumps(receipt,indent=2))
    before=evaluate(a.checkpoint,session,a.python,'before')
    # Real native updates validate checkpoint compatibility before long training.
    if a.lane=='rlinf':
        for stage,count in [('smoke',64),('capacity',2048)]:
            run_phase('A2',session/stage,a.python,count,2,initial_checkpoint=a.checkpoint)
        model=run_phase('A2',session/'training',a.python,2048,750,initial_checkpoint=a.checkpoint)
        state=torch.load(model,map_location='cpu',weights_only=False)
        policy.load_state_dict(state,strict=True)
        checkpoint=session/'rlinf_policy_for_reference_eval.pt'
        torch.save(dict(model_state_dict=state,optimizer_state_dict=torch.optim.Adam(policy.parameters(),lr=.001).state_dict(),iter=750),checkpoint)
    else:
        # Exercise this exact weight-only loading path at both environment counts.
        for stage,count in [('smoke',64),('capacity',2048)]:
            probe_args=source_recipe('A2',0)
            for flag,value in [('--max_iterations',2),('--num_envs',count),
                               ('--experiment_name','switch_probe_'+session.name+'_'+stage)]:
                probe_args[probe_args.index(flag)+1]=str(value)
            probe_args+=['--pretrained_checkpoint',str(a.checkpoint)]
            checked([str(a.python),str(ROOT/'a40/switch_rsl_train.py'),*probe_args],session/stage)
            probe_models=list((ROOT/'benchmark/logs/rsl_rl'/('switch_probe_'+session.name+'_'+stage)).glob('*/model_*.pt'))
            if not probe_models:raise RuntimeError('Weight-only RSL probe produced no checkpoint')
            probe_state=torch.load(max(probe_models,key=lambda f:f.stat().st_mtime_ns),map_location='cpu',weights_only=False)['model_state_dict']
            if not all(torch.isfinite(v).all() for v in probe_state.values()):raise RuntimeError('Non-finite RSL probe')
            if not any(not torch.equal(v,state[k]) for k,v in probe_state.items()):raise RuntimeError('RSL probe did not update weights')
        args=source_recipe('A2',0)
        def setflag(flag,value):args[args.index(flag)+1]=str(value)
        experiment='switch_A2_mid_rsl_'+session.name
        setflag('--max_iterations',750);setflag('--experiment_name',experiment)
        args+=['--pretrained_checkpoint',str(a.checkpoint)]
        checked([str(a.python),str(ROOT/'a40/switch_rsl_train.py'),*args],session/'training')
        models=list((ROOT/'benchmark/logs/rsl_rl'/experiment).glob('*/model_*.pt'))
        if not models:raise RuntimeError('No RSL checkpoint')
        checkpoint=max(models,key=lambda f:f.stat().st_mtime_ns)
    final_state=torch.load(checkpoint,map_location='cpu',weights_only=False)['model_state_dict']
    if not all(torch.isfinite(v).all() for v in final_state.values()):raise RuntimeError('Non-finite final weights')
    initial=torch.load(a.checkpoint,map_location='cpu',weights_only=False)['model_state_dict']
    if not any(not torch.equal(v,initial[k]) for k,v in final_state.items()):raise RuntimeError('Weights unchanged')
    after=evaluate(checkpoint,session,a.python,'after')
    (session/'result.json').write_text(json.dumps(dict(status='verified',protocol=receipt,before=before,after=after,
        success_rate_change=after['success_rate']-before['success_rate'],checkpoint=str(checkpoint)),indent=2))

if __name__=='__main__':main()
