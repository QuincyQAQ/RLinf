#!/usr/bin/env python3
"""OpenSSH ProxyCommand: bind DNS and TCP to a physical NIC, bypassing TUN per socket."""
from __future__ import annotations

import argparse
import ipaddress
import os
import secrets
import select
import socket
import struct
import sys


def bound_socket(kind, interface):
    sock = socket.socket(socket.AF_INET, kind)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BINDTODEVICE, interface.encode() + b"\0")
    sock.settimeout(8)
    return sock


def resolve(host, interface, dns):
    try:
        return str(ipaddress.IPv4Address(host))
    except ipaddress.AddressValueError:
        pass
    ident = secrets.randbelow(65536)
    packet = struct.pack("!HHHHHH", ident, 0x100, 1, 0, 0, 0)
    packet += b"".join(bytes([len(part)]) + part.encode("ascii") for part in host.split("."))
    packet += b"\0" + struct.pack("!HH", 1, 1)
    with bound_socket(socket.SOCK_DGRAM, interface) as sock:
        sock.sendto(packet, (dns, 53))
        data, peer = sock.recvfrom(4096)
    response_id, flags, questions, answers, _, _ = struct.unpack("!HHHHHH", data[:12])
    if peer[0] != dns or response_id != ident or not flags & 0x8000 or flags & 0x20f:
        raise RuntimeError("Invalid, truncated or unsuccessful campus DNS response")

    def skip_name(offset):
        while data[offset]:
            if data[offset] & 0xc0 == 0xc0:
                return offset + 2
            offset += data[offset] + 1
        return offset + 1

    offset = 12
    for _ in range(questions):
        offset = skip_name(offset) + 4
    for _ in range(answers):
        offset = skip_name(offset)
        kind, cls, ttl, size = struct.unpack("!HHIH", data[offset:offset + 10])
        offset += 10
        if kind == 1 and cls == 1 and size == 4:
            address = socket.inet_ntoa(data[offset:offset + size])
            if ipaddress.IPv4Address(address) in ipaddress.IPv4Network("198.18.0.0/15"):
                raise RuntimeError("DNS still returned a proxy virtual address")
            return address
        offset += size
    raise RuntimeError("Campus DNS returned no IPv4 address")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interface", default="wlp3s0")
    parser.add_argument("--dns", default="10.90.63.2")
    parser.add_argument("host")
    parser.add_argument("port", type=int)
    args = parser.parse_args()
    address = resolve(args.host, args.interface, args.dns)
    with bound_socket(socket.SOCK_STREAM, args.interface) as sock:
        sock.connect((address, args.port))
        sock.settimeout(None)
        print(f"Direct SSH via {args.interface}: {args.host} -> {address}:{args.port}", file=sys.stderr)
        stdin_open = True
        while True:
            readable, _, _ = select.select([sock, 0] if stdin_open else [sock], [], [])
            if 0 in readable:
                chunk = os.read(0, 65536)
                if chunk:
                    sock.sendall(chunk)
                else:
                    stdin_open = False
                    sock.shutdown(socket.SHUT_WR)
            if sock in readable:
                chunk = sock.recv(65536)
                if not chunk:
                    return
                while chunk:
                    chunk = chunk[os.write(1, chunk):]


if __name__ == "__main__":
    try:
        main()
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"Direct SSH failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
