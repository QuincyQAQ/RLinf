#!/usr/bin/env bash
#SBATCH --job-name=go2_switch_A2_mid
#SBATCH --partition=emergency_gpua40
#SBATCH --account=root
#SBATCH --qos=emergency_gpua40
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=06:00:00
#SBATCH --output=slurm_%x_%j.out
#SBATCH --error=slurm_%x_%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?Submit from project root}"
SWITCH_LANE=${1:?rsl or rlinf}
case "$SWITCH_LANE" in rsl|rlinf) ;; *) exit 2 ;; esac
bash a40/hpc_environment.sh run-rlinf-switch --lane "$SWITCH_LANE" \
 --checkpoint /workspace/go2/benchmark/logs/rsl_rl/unitree_go2_a2_baseline_2048_seeds/2026-11-19_20-27-02_A2_omni_2048_s0/model_750.pt
