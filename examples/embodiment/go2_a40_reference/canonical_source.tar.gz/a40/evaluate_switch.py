"""Original A2 evaluator with an explicitly fixed environment seed."""
import importlib.util
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'benchmark/scripts'))
spec=importlib.util.spec_from_file_location('switch_original_eval',ROOT/'benchmark/scripts/evaluate.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.gym.make

def make(task,*args,**kwargs):
    kwargs['cfg'].seed=12345
    m.torch.manual_seed(12345)
    return original(task,*args,**kwargs)
m.gym.make=make
try:
    m.main()
finally:
    m.simulation_app.close()
