#!/usr/bin/env bash
# Current batch: five original specialists, seed 0 only. Eight-card concurrency
# ceiling retained; only five one-card tasks exist, so at most five cards are used.
#SBATCH --job-name=go2_ind_rsl_A1
#SBATCH --partition=emergency_gpua40
#SBATCH --account=root
#SBATCH --qos=emergency_gpua40
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=1-00:00:00
#SBATCH --output=slurm_%x_%j.out
#SBATCH --error=slurm_%x_%j.err
set -euo pipefail
TASK_ROOT="${SLURM_SUBMIT_DIR:?Submit from the prepared project root}"
cd "$TASK_ROOT"
TASK_NAMES=(A1 A2 B1 B2 C2)
TASK_INDEX=0
[[ "$TASK_INDEX" -ge 0 && "$TASK_INDEX" -lt 5 ]] || exit 2
TASK_SEED=0
TASK_NAME="${TASK_NAMES[$TASK_INDEX]}"
echo "Job $SLURM_JOB_ID array $SLURM_JOB_ID/$TASK_INDEX: $TASK_NAME seed=$TASK_SEED started $(date -Is) on $(hostname)"
trap 'TASK_EXIT=$?; echo "Array task finished $(date -Is), exit=$TASK_EXIT"; exit "$TASK_EXIT"' EXIT
python3 - <<'PY'
import json
from pathlib import Path
j=json.loads(Path('validation/PRESTART_READY.json').read_text())
assert not j['errors'] and j['training_pip_check_clean']
PY
# Allocation chooses the visible GPU; never overwrite CUDA_VISIBLE_DEVICES.
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader
bash a40/hpc_environment.sh run train --task "$TASK_NAME" --seed "$TASK_SEED" \
  --asset-source mirror --execute
