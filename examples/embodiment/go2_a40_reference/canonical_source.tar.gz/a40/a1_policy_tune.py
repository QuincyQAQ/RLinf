"""Bounded A1 RLinf robustness tuning with separate selection and final evaluation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time
import traceback
from reference import ROOT,verify_source
from b2_continuation import native,ordinary,evaluate,validate,write

CANDIDATES={
 'low_entropy':dict(lr=1e-4,entropy_bonus=.001,value_loss_type='huber',desired_kl=.003),
 'zero_entropy':dict(lr=1e-4,entropy_bonus=0.,value_loss_type='huber',desired_kl=.003),
}
VALIDATION_SEED=56789
HOLDOUT_SEEDS=[67890,78901]
ADDITIONAL_UPDATES=500

def rank(row):
    return (-row['success_rate'],row['mean_lin_vel_error'],row['mean_ang_vel_error'])

def main():
    p=argparse.ArgumentParser();p.add_argument('--python',required=True);a=p.parse_args()
    assert os.environ.get('SLURM_JOB_ID');verify_source()
    old=ROOT/'outputs/fullppo_huber_A1_14029742'
    assert json.loads((old/'result.json').read_text())['status']=='verified'
    source=old/'rlinf_huber/training/policy.pt'
    control=Path(json.loads((old/'rsl_control/training/validation.json').read_text())['checkpoint'])
    for model in [source,control]:validate(model)
    root=ROOT/'outputs'/('a1_policy_tune_'+os.environ['SLURM_JOB_ID']);root.mkdir()
    hashes={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [source,control]}
    protocol=dict(task='A1',training_seed=0,source_updates=4000,additional_updates=ADDITIONAL_UPDATES,
        total_updates_per_trained_lane=4500,num_envs=2048,rollout_steps=24,
        additional_transitions_per_trained_lane=24576000,sources=dict(rlinf=str(source),rsl=str(control)),
        recipes=CANDIDATES,optimizer='fresh per lane',environment='fresh per lane',
        validation_seed=VALIDATION_SEED,holdout_seeds=HOLDOUT_SEEDS,
        selection='best validation tracking rate, then linear error, then angular error; untuned eligible; fixed tie order',
        stopping='two fixed RLinf candidates only; no holdout-based retuning',
        evaluation_minimum_episodes_per_seed=1024,task_reward_network_changes=False,
        ordinary_control='own completed4000-update PPO checkpoint plus500 original PPO updates',
        caveat='tuned method with extra selection compute; one training seed; no framework-only causal claim; 100% not guaranteed')
    write(root/'protocol.json',protocol)
    results={};validation={};models={'untuned':source};failed_candidates={}
    def progress(stage,**kwargs):write(root/'progress.json',dict(stage=stage,time=time.time(),**kwargs))
    try:
        progress('validation',lane='untuned')
        validation['untuned']=evaluate(a.python,source,root/'untuned'/'validation',VALIDATION_SEED,'A1')
        write(root/'validation_results.json',validation)
        for name,recipe in CANDIDATES.items():
            try:
                for stage,count in [('smoke',64),('capacity',2048)]:
                    progress(stage,lane=name)
                    native(a.python,source,root/name/stage,recipe,count,2,'A1',start_iteration=4000)
                progress('training',lane=name,updates=ADDITIONAL_UPDATES)
                models[name]=native(a.python,source,root/name/'training',recipe,2048,ADDITIONAL_UPDATES,'A1',start_iteration=4000)
                progress('validation',lane=name)
                validation[name]=evaluate(a.python,models[name],root/name/'validation',VALIDATION_SEED,'A1')
                write(root/'validation_results.json',validation)
            except Exception as exc:
                failed_candidates[name]=dict(error=repr(exc),traceback=traceback.format_exc())
                write(root/'failed_candidates.json',failed_candidates)
                progress('candidate_failed',lane=name,error=repr(exc))
        selected=min(validation,key=lambda name:rank(validation[name]))
        selection=dict(selected=selected,model=str(models[selected]),validation_seed=VALIDATION_SEED,
                       validation_metrics=validation[selected],frozen_before_holdout=True)
        write(root/'selection.json',selection)
        for stage,count in [('smoke',64),('capacity',2048)]:
            progress(stage,lane='rsl_matched')
            ordinary(a.python,control,root/'rsl_matched'/stage,count,2,'A1')
        progress('training',lane='rsl_matched',updates=ADDITIONAL_UPDATES)
        matched=ordinary(a.python,control,root/'rsl_matched'/'training',2048,ADDITIONAL_UPDATES,'A1')
        finals={'untuned_rlinf_4000':source,'ordinary_ppo_4000':control,
                'ordinary_ppo_4500':matched,'selected_rlinf':models[selected]}
        cache={}
        for name,model in finals.items():
            results[name]={}
            for seed in HOLDOUT_SEEDS:
                progress('holdout_evaluation',lane=name,seed=seed)
                key=(str(model),seed)
                if key not in cache:cache[key]=evaluate(a.python,model,root/'holdout'/name/str(seed),seed,'A1')
                results[name][str(seed)]=cache[key]
                write(root/'partial_results.json',dict(selection=selection,results=results))
        pooled={}
        for name,rows in results.items():
            count=sum(row['num_episodes'] for row in rows.values())
            successes=sum(round(row['num_episodes']*row['success_rate']) for row in rows.values())
            pooled[name]=dict(episodes=count,successes=successes,tracking_rate=successes/count,
                **{metric:sum(row[metric]*row['num_episodes'] for row in rows.values())/count
                   for metric in ['mean_lin_vel_error','mean_ang_vel_error']})
        assert hashes=={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [source,control]}
        write(root/'result.json',dict(status='verified',protocol=protocol,selection=selection,
             all_validation_results=validation,failed_candidates=failed_candidates,holdout_results=results,pooled_holdout=pooled,original_sha256=hashes))
        progress('completed')
    except BaseException as exc:
        write(root/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc()))
        progress('failed',error=repr(exc));raise

if __name__=='__main__':main()
