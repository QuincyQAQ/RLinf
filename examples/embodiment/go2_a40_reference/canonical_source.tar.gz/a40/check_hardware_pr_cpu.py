#!/usr/bin/env python3
"""Exercise the isolated hardware PR against vendor SDK fakes; never connect DDS."""
import datetime as dt
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "contribution/go2_hardware/RLinf"


def main():
    os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    sys.path[:0] = [str(REPO), str(REPO / "tests")]
    os.chdir(REPO)
    import pytest

    output = ROOT / "contribution/go2_hardware/validation"
    output.mkdir(exist_ok=True)
    code = pytest.main(["tests/unit_tests/test_robotics.py", "tests/unit_tests/test_real_env.py",
                        "-k", "go2 or state_only_real_env", "-q", "-ra",
                        "--junitxml=" + str(output / "hardware_pytest.xml")])
    report = {"checked_at": dt.datetime.now(dt.timezone.utc).isoformat(), "exit_code": int(code),
              "status": "passed" if code == 0 else "failed", "gpu_used": False,
              "hardware_connected": False, "vendor_edge": "tests/robot_mocks/unitree_go2.py",
              "repository": str(REPO), "scope": "Go2 robot and real-environment CPU tests on isolated migrated code"}
    (output / "hardware_cpu_checks.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    raise SystemExit(code)


if __name__ == "__main__":
    main()
