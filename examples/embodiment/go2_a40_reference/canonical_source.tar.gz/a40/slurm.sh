#!/usr/bin/env bash
# Use the site's Slurm 23.02 clients, including in non-login SSH shells.
# No command, allocation, or submission runs unless explicitly supplied.
set -euo pipefail
[[ $# -gt 0 ]] || { echo 'Usage: bash a40/slurm.sh <Slurm command> [args]' >&2; exit 2; }
case "$1" in
  sinfo|squeue|scontrol|sacctmgr|sacct|sbatch|srun|salloc|scancel) ;;
  *) echo 'Expected an explicit Slurm command' >&2; exit 2 ;;
esac
[[ -x "/opt/slurm/bin/$1" ]] || { echo 'Site Slurm installation missing' >&2; exit 2; }
export LD_LIBRARY_PATH="/opt/slurm/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
TASK_COMMAND="$1"
shift
exec "/opt/slurm/bin/$TASK_COMMAND" "$@"
