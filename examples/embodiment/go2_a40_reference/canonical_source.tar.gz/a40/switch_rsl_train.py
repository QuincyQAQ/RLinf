"""Run original A2 trainer with weight-only initialization and fresh optimizer."""
import importlib.util
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'benchmark/scripts'))
spec=importlib.util.spec_from_file_location('switch_original_train',ROOT/'benchmark/scripts/train.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.OnPolicyRunner.load

def load_weights(self,path,*args,**kwargs):
    result=original(self,path,load_optimizer=False)
    self.current_learning_iteration=0
    print('[SWITCH] Weight-only initialization; fresh optimizer and iteration zero',flush=True)
    return result
m.OnPolicyRunner.load=load_weights
try:
    m.main()
finally:
    m.simulation_app.close()
