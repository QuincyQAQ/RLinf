"""Release only pending native jobs after the attached compute step and reports pass."""
import argparse
import json
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parents[1]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--job',type=int,required=True)
    p.add_argument('--step',required=True);a=p.parse_args()
    result=ROOT/f'validation/compute_rlinf_{a.job}/result.json'
    manifest=ROOT/'outputs/jobs/container_recovery_seed0.json'
    status=ROOT/'outputs/jobs/attached_native_gate.json'
    deadline=time.monotonic()+660
    while True:
        lines=subprocess.check_output(['/opt/slurm/bin/sacct','-n','-j',str(a.job),
             '--format=JobID,State,ExitCode','-P'],text=True).splitlines()
        row=next((x.split('|') for x in lines if x.startswith(a.step+'|')),None)
        state=row[1] if row else 'UNKNOWN'
        report=dict(step=a.step,state=state,updated=time.time(),result=str(result))
        status.write_text(json.dumps(report,indent=2))
        if state=='COMPLETED' and row[2]=='0:0':
            data=json.loads(result.read_text())
            assert all(data[s]['status']=='passed' and data[s]['updates']==2 and
                       data[s]['finite_weights'] for s in ['smoke','capacity'])
            d=json.loads(manifest.read_text());jobs=[x['new_job'] for x in d['jobs'] if 'rlinf' in x['script']]+[14019304]
            released=[]
            for j in jobs:
                s=subprocess.check_output(['/opt/slurm/bin/squeue','-h','-j',str(j),'-o','%T'],text=True).strip()
                if s=='PENDING':
                    subprocess.run(['/opt/slurm/bin/scontrol','update',f'JobId={j}','Dependency='],check=True)
                    released.append(j)
            d['native_attached_preflight'].update(stage='passed',finished=time.time(),result=data)
            manifest.write_text(json.dumps(d,indent=2))
            report.update(state='passed_and_released',released=released)
            status.write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True);return
        if state in ['FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY'] or time.monotonic()>deadline:
            raise RuntimeError(f'Attached native preflight did not pass: {state}')
        time.sleep(10)


if __name__=='__main__':main()
