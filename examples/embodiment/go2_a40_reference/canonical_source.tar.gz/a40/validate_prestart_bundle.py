#!/usr/bin/env python3
"""Audit prepared files and existing CPU receipts. Never launches a simulation."""
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def load(relative):
    return json.loads((ROOT / relative).read_text())


def main():
    errors = []
    status = load("validation/prestart_status.json")
    if status["status"] != "non_simulation_preparation_complete":
        errors.append("Non-simulation preparation has not finished")
    core = load("validation/container_verify.json")
    if core["status"] != "passed" or core.get("isolated_asset_tools_on_training_path", True):
        errors.append("Core environment failed or the independent USD tool leaked")
    dependencies = load("validation/container_dependency_audit.json")
    isolation = load("validation/usd_isolation_ready.json")
    converter = load("validation/usd_converter_check.json")
    scheduler = load("validation/cluster_scheduler_query.json")
    if not dependencies["global_pip_check_clean"] or isolation["status"] != "passed":
        errors.append("Training dependency isolation has not passed")
    if converter["status"] != "passed" or not converter["pip_check_clean"]:
        errors.append("Standalone USD converter has not passed")
    if not scheduler.get("account_permission_metadata_verified"):
        errors.append("Live scheduler account permission metadata has not passed")
    mirror = load("validation/asset_mirror.json")
    if mirror["status"] != "passed" or mirror["robot_revolute_joint_count"] != 12:
        errors.append("Go2 asset mirror/model check failed")
    for entry in mirror["files"]:
        path = ROOT / entry["local_path"]
        if not path.is_file() or path.stat().st_size != entry["bytes"]:
            errors.append("Missing or incomplete asset: " + entry["local_path"])
    mounts = load("validation/container_mount_preflight.json")
    if mounts["status"] != "passed" or not mounts["cache_write_verified"]:
        errors.append("Container filesystem preflight failed")
    archive = ROOT / "reference_archive/hkust_20261119"
    manifest = load("reference_archive/hkust_20261119/TRANSFER_MANIFEST.json")
    for entry in manifest["files"]:
        path = archive / entry["target"]
        if not path.is_file() or path.stat().st_size != entry["bytes"]:
            errors.append("Reference transfer is incomplete: " + entry["target"])
    plan = load("validation/cluster_seed0_plan.json")
    if len(plan["commands"]) != 5 or plan["seed"] != 0:
        errors.append("Expected the five-task seed-0 original baseline plan")
    for command in plan["commands"].values():
        if any(flag in command for flag in ["--checkpoint", "--resume", "--pretrained_checkpoint"]):
            errors.append("The scratch baseline unexpectedly loads an old policy")
    subprocess.run([sys.executable, "a40/reference.py", "check"], cwd=ROOT, check=True)
    subprocess.run(["bash", "-n", "a40/hpc_environment.sh", "a40/container_python.sh",
                    "a40/complete_prestart.sh", "a40/a40_job.sbatch", "a40/training_python.sh",
                    "a40/slurm.sh", "a40/prepare_usd_isolation.sh"], cwd=ROOT, check=True)
    report = {"status": "passed_with_documented_external_limits" if not errors else "failed",
              "finished_unix": time.time(), "errors": errors,
              "training_input_dataset_required": False, "procedural_terrain": True,
              "asset_files": mirror["file_count"], "asset_bytes": mirror["total_bytes"],
              "archived_reference_models": len(load("reference_archive/hkust_20261119/MODEL_CONTRACTS.json")["models"]),
              "reference_models_used_for_initialization": False,
              "unresolved_dependency_issues": dependencies["active_environment"]["issues"],
              "training_pip_check_clean": dependencies["global_pip_check_clean"],
              "converter_pip_check_clean": converter["pip_check_clean"],
              "original_image_modified": False,
              "original_image_diagnostics": dependencies["baseline_image"]["issues"],
              "scheduler_live_query": scheduler["status"],
              "account_permission_metadata_verified": scheduler["account_permission_metadata_verified"],
              "account_allocation_verified": False, "gpu_job_submitted": False,
              "simulation_started": False, "training_started": False,
              "remaining": ["allocated A40 driver/Vulkan",
                            "Isaac Sim environment creation, 64-env and full-count PPO checks"]}
    (ROOT / "validation/PRESTART_READY.json").write_text(json.dumps(report, indent=2))
    readiness = load("validation/READINESS.json")
    readiness.update(state=report["status"], global_pip_check_clean=dependencies["global_pip_check_clean"],
                     unresolved_base_image_dependency_issues=dependencies["baseline_image"]["issues"],
                     unresolved_training_dependency_issues=dependencies["active_environment"]["issues"],
                     converter_pip_check_clean=converter["pip_check_clean"],
                     scheduler_account_access_verified=scheduler["account_permission_metadata_verified"],
                     required_A40_checks=report["remaining"])
    (ROOT / "validation/READINESS.json").write_text(json.dumps(readiness, indent=2))
    print(json.dumps(report, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
