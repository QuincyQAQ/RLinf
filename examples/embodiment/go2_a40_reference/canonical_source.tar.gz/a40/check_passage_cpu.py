#!/usr/bin/env python3
"""Record CPU-only checks for the additive same-episode obstacle evaluator."""
from __future__ import annotations

import datetime as dt
import io
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


def main():
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    import torch
    import numpy as np
    import trimesh

    output = ROOT / "validation"
    output.mkdir(exist_ok=True)
    (output / "passage_cpu_tests.txt").write_text(stream.getvalue())
    report = {"status": "passed" if result.wasSuccessful() else "failed",
              "checked_at": dt.datetime.now(dt.timezone.utc).isoformat(),
              "tests_run": result.testsRun, "failures": len(result.failures), "errors": len(result.errors),
              "python": sys.version, "torch": torch.__version__, "numpy": np.__version__,
              "trimesh": trimesh.__version__, "gpu_used": False, "simulation_started": False,
              "production_gpu_validation": "pending_allocated_a40_run",
              "geometry_tests": "Actual original mesh generator functions executed on CPU; no simulator imports",
              "runtime_tests": "Mock SDK tensors and original EpisodeStatsTracker; not physical simulation results",
              "source_and_cli_checks_included": True,
              "test_log": str(output / "passage_cpu_tests.txt")}
    (output / "passage_cpu_checks.json").write_text(json.dumps(report, indent=2))
    print(stream.getvalue())
    print(json.dumps(report, indent=2))
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == "__main__":
    main()
