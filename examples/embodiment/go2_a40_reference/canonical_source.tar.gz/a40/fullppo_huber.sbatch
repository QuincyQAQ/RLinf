#!/usr/bin/env bash
#SBATCH --job-name=go2_fullppo_huber
#SBATCH --partition=emergency_gpua40
#SBATCH --account=root
#SBATCH --qos=emergency_gpua40
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=4
#SBATCH --mem=64G
#SBATCH --time=12:00:00
#SBATCH --nice=0
#SBATCH --exclude=gpu3-13
#SBATCH --output=slurm_%x_%j.out
#SBATCH --error=slurm_%x_%j.err
set -euo pipefail
cd "${SLURM_SUBMIT_DIR:?}"
TASK_EXTRA=()
if [[ "${1:?A1 A2 B1 or C2}" == B1 ]]; then TASK_EXTRA+=(--repair-b1); fi
bash a40/hpc_environment.sh run-rlinf-fullppo --task "$1" "${TASK_EXTRA[@]}"
