# USD 依赖与 Slurm 修复记录（2026-11-19）

只修改本次独立准备目录，原 SIF、benchmark、IsaacLab、旧本机/hkust 工程和任务均保留。没有 sudo、GPU 分配、作业提交、Kit/物理仿真或训练。

## USD 依赖：分别运行两套不兼容工具

原镜像同时暴露两个互不兼容的可选工具栈：

- `nvidia-srl-usd-to-urdf==1.0.2` 要求 `lxml>=4.9.2,<5` 和 `usd-core>=25.2.post1,<26`。
- `dex-retargeting==0.4.6` 要求 `lxml>=5.2.2`。

同一个 Python 进程没有符合两者约束的 lxml 版本；给仿真器随意安装 pip USD 还会覆盖 SDK 自带的 USD。因此采用进程隔离，未改软件包元数据来掩盖错误。

训练入口仍调用官方 `/isaac-sim/python.sh`。仅在它完成环境设置后，通过 `PYTHONEXE=a40/training_python.sh` 排除 `isaacsim.asset.exporter.urdf/pip_prebundle` 路径；该 prebundle 的转换器及其依赖不再作为 locomotion 的全局包暴露。训练辅助层保留同版本 lxml 5.4.0。原 SDK 的 USD 扩展未替换，Go2 仍加载已准备的 USD 模型，五项任务和 PPO 参数未更改。此边界适用于本项目 locomotion；若未来在同进程启用 URDF exporter 或其他依赖它的任务，应另外验证，不能套用本验收。

USD 转换在 `.usd_converter` 独立 venv 使用原版本转换器、usd-core 25.2.post1、lxml 4.9.4、NumPy 1.26.4。启动器清除训练 PYTHONPATH，只为该子进程设置其 USD 动态库。完整选定依赖在 `config/usd-converter.lock.txt`，训练辅助层在 `config/prestart-extra.lock.txt`。`.asset_tools` 继续只用于资产镜像解析。

实际 CPU 验收：

- 训练入口 `pip check`：退出 0，`No broken requirements found.`
- 转换环境 `pip check`：退出 0。
- 实际生成双连杆、一个转动关节的 USD，调用 `UsdToUrdf` 转出 URDF，XML 验证至少两个 link、一个 revolute joint 和有效父子引用。
- 训练核心版本、CPU 张量运算和 RSL-RL 导入通过；转换器 Python 路径没有进入训练路径。
- 原始镜像自身仍保留历史 7 条诊断；当前活动训练/转换入口检查均干净。原镜像的历史诊断与活动入口结果在报告中分开记录。

证据：`validation/usd_converter_check.json`、`usd_isolation_ready.json`、`container_dependency_audit.json`、`container_verify.json`。

CPU 复查命令（不启动模拟器）：

```bash
bash a40/hpc_environment.sh python-cpu -m pip check
bash a40/hpc_environment.sh python-cpu a40/usd_converter.py -m pip check
bash a40/hpc_environment.sh python-cpu a40/usd_converter.py a40/check_usd_converter.py
```

新环境重建使用 `bash a40/prepare_usd_isolation.sh`；只有两边检查通过后才写入启用凭据。GPU runtime probe 会额外检查实际 Kit 加载的 USD 来源，拒绝使用 `.usd_converter` 或 `.asset_tools` 的 USD。实际 Kit/PhysX 测试仍未运行。

## Slurm：非登录 SSH 调用了错误的系统客户端

最初非登录 SSH 的 PATH 选择 `/usr/bin/sinfo`、`/usr/bin/sacctmgr`，查询超时。集群登录环境的 Slurm module 提供 `/opt/slurm/bin` 及 `/opt/slurm/lib`。改用该客户端后，六项只读查询均在一秒内返回。

`a40/slurm.sh` 显式选择集群客户端，不修改全局 PATH、module 或 SSH 配置。`a40/check_scheduler.py` 只调用只读命令，并保存原始结果和耗时。

实时核实结果：

- 客户端：Slurm 23.02.3。
- A40 队列 `i64m1tga40u`：UP，3 节点、共 24 张 A40 配置容量；不是空闲数量。
- 用户 `qli736` 的默认调度账户为 `root`，这是账户名，不代表 OS root 权限。
- 用户关联允许 `i64m1tga40u` QoS；该分区 AllowGroups/AllowAccounts/AllowQos 均为 ALL。
- 该 QoS 每用户上限：128 CPU、16 GPU（A40 上限 16 卡），最多 50 个提交作业。上限不等于当前可分配或可付费资源。
- `squeue --me` 当时为空。本轮没有提交任务，也没有验证余额、真实资源分配或保证排队时间。

证据：`validation/cluster_scheduler_query.json`。模板已写入核实到的 account/QoS，未来提交须使用 `bash a40/slurm.sh sbatch a40/a40_job.sbatch`，避免非登录 shell 再选错客户端。

只读复查：`python3 a40/check_scheduler.py`。实际 GPU/驱动/Vulkan、环境创建与 PPO 容量短测仍留待获配 A40 后执行。
