# B1 numerical diagnosis — current repair

The current repair is **only an action/history bound of ±100 before ActionManager
stores the raw action**, shared by native PPO, RLinf and seeded evaluation. All
original reward functions, weights, terminations, network and PPO hyperparameters
are preserved. The earlier physical-failure boundary and -1 failure reward below
are historical experiments, removed from the active implementation because they
failed to address the actual feedback path.

## Located mechanism

Job14032129 captured the first actor input above1e4. Environment510 had extreme
values only in columns36:48, the previous-action observation (maximum19152.4).
Position, quaternion, root velocities, joint velocities and ray hits were finite
and physically ordinary (largest joint speed21.69rad/s). The previous action is
fed back into the actor without bounds, so a learned autoregressive feedback
loop amplified actions until the value loss overflowed. This explains why checking
only physical state and std did not fix the problem. Snapshot retained remotely:
`outputs/b1_diagnostic_14032129/failure_capture/failure.pt`.

## Minimal repaired execution

- Recovery14032252: original model2850+Adam state, remaining149 updates to3000,
  original2048 envs,seed0 and unchanged PPO parameters, with action/history bound100.
- Real GPU regression14032253: raw action10000 became recorded action100 and
  previous-action observation100; two actual updates produced changed finite
  actor/critic parameters and positive std. Completed0, structured passed result.
- Comparison14032301: afterok on BOTH recovery14032252 and regression14032253.
  Runs original extra1000 PPO control and frozen B2 RLinf-Huber extra1000, shared
  repaired action contract and held-out evaluation seeds23456/34567.
- CPU regression suite48 passed. Invalid nonfinite actions still raise explicitly;
  no loss replacement, gradient zeroing or skipped updates.

The action boundary is disclosed as a minimal environment-interface repair, not
an unchanged original run. Recovery14032252 completed149/149 updates, yielding a finite valid iter2999
checkpoint. Comparison14032301 validated its source and BOTH learners passed
64/2048-env real-update gates (changed actor/critic, finite, positive std). It is
now evaluating the baseline, then automatically runs both1000-update lanes and
holdouts. Long continuation and final quantitative evaluation remain pending.
Earlier failed recovery and diagnostic artifacts remain preserved.

---

## Historical diagnosis (superseded where noted)

# B1 numerical diagnosis and minimal-change recovery

B1 original final weights are nonfinite. Resuming model1100, model1050 and
model1000 with restored Adam state and unchanged configuration failed again.
All three failures were rejected before an optimizer update could corrupt the
model further. Protection is not a root-cause repair.

The last saved checkpoint from the model1000 recovery attempt is model2650:
`benchmark/logs/rsl_rl/b1_source_repair_14029762_1000_training/2026-11-20_11-11-51_B1_rough_2048_s0/model_2650.pt`.
CPU inspection found all weights finite, maximum absolute weight 1.586,
standard deviations approximately 0.31–0.64 and Adam learning rate 0.00011390625.
No evidence at this point supports a vanishing-standard-deviation diagnosis.

Job14031320 resumes this checkpoint and optimizer for the remaining349 updates
to3000, with original seed0,2048 environments,235 observations,12 actions,
network,rewards,terrain and PPO configuration. It adds failure capture only.
Job14031315 failed before simulation because the diagnostic mode did not expose
the existing RLinf checkpoint-validation dependency; that container path was
corrected. Preserve its logs; it is not a failed training trial.

`a40/b1_diagnostics.py` distinguishes nonfinite network inputs, nonfinite PPO
losses, nonfinite gradients before clipping and finite-gradient norm overflow.
It saves the actual failing batch tensors, model weights, tensor statistics and
reason under the job's output directory. It does not silently replace invalid
observations, zero gradients or discard minibatches. CPU regression checks cover
bad-gradient detection, norm overflow detection and acceptance of a valid update.
Diagnostic tracing changes timing, so exclude it from throughput comparisons.

The source terrain-relative base-height reward uses an unmasked mean of ray-hit
heights. A missed ray is a candidate source of invalid reward, not a confirmed
root cause yet. The numerical snapshot must determine the first invalid quantity
before changing this function or changing a training hyperparameter.

Live status: `outputs/b1_diagnostic_14031320/training/console.log` and
`outputs/b1_diagnostic_14031320/failure_capture/failure.json`.
Do not claim this diagnostic is a completed repair or valid final benchmark.

## Captured failure and guarded recovery

Diagnostic14031320 reproduced failure with finite model parameters (maximum
absolute weight1.593) and normal std, but six batch returns above1e6, reaching
1.9359e20. Raw action means reached1.6521e11. Squared value loss overflowed
float32; advantage normalization collapsed to zero. The batch/model snapshot is
retained in outputs/b1_diagnostic_14031320/failure_capture/failure.pt. This
confirms an extreme-data loss-overflow mechanism, not vanishing std. The original
physical trigger (contact solver excursion, missed terrain ray or other state
corruption) is not yet uniquely isolated.

The repair adds only an explicit B1 simulator-validity failure boundary, at
root speed100m/s, angular speed200rad/s, joint speed1000rad/s, joint angle20rad,
terrain-relative root height magnitude5m, nonfinite state or missed terrain ray.
These are generous validity limits, not task difficulty tuning. Invalid episodes
terminate as failures, original reward terms are masked only for those episodes,
and an explicit -1 terminal reward is applied. All normal rewards remain exact.
No replacement gradients, skipped updates, changed learning rates or reward
weights for normal states. Abort if validity failures exceed0.1% of checked
transitions after10000 checks. Both continuation learners and their evaluations
use the same opt-in boundary. This is a disclosed environment repair and must
not be presented as an unchanged original benchmark.

Recovery14031449 restores the last finite2650 checkpoint plus Adam state and
trains remaining349 updates. Dependent comparison14031461 requires both its
success and the boundary-reset GPU regression14031466. The old impossible
afterok job14031388 was cancelled.

GPU regression14031466 completed0: one intentionally invalid simulated root
height caused exactly one explicit failure/reset, followed by two real PPO
updates with changed actor/critic, finite saved model and positive std. This
checks reset behavior, not long-run convergence. CPU tests49 passed. Full
recovery and comparison remain in progress at this record.

## Independent feedback recurrence check

With the actual failing previous-action vector and fixed physical/sensor fields,
the captured actor diverged to infinity after96 deterministic recurrence steps
without a bound. With ±100 action/history bound,1000 recurrence steps remained
finite. Starting from a zero previous-action vector at the same fixed physical
state instead settled to a finite attractor, so the test establishes amplification
from the observed failing trajectory, not inevitable divergence of every state.
Local artifact: tests/b1_action_feedback.json.
