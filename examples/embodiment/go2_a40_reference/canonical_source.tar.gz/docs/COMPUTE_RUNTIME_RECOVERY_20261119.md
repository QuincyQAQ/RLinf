# A40 compute-node runtime recovery

The eight A1/A2/B1/B2 seed-zero jobs received gpu3-6 allocations at 19:32–19:33
on 2026-11-19 and failed before training. Apptainer could not extract the SIF:
squashfuse was absent and unprivileged user namespaces were disabled.
Login-node container validation had not established compute-node compatibility.

Immediate checks used allocated debug nodes rather than waiting for the regular
A40 queue. CPU job14021610 ran Python3.11.13 inside the existing user-owned
official-image extraction. A40 job14021619 completed successfully on gpu3-9:
PyTorch2.7.0+cu128, NVIDIA A40, exactly one visible GPU.

Singularity CE4.1.3 is the cluster-provided alternative runtime. The original SIF
has a root-owned mode750 `/isaac-sim`; the existing extraction belongs to qli736
and is readable by the allocated process. On GPFS, Singularity falls back to
underlay and disables writable-tmpfs. The official SIF and upstream code remain
unchanged. The activation receipt records the scope as container/Python/CUDA only.

Real Kit/PPO probing exposed two additional preparation defects:

- Shared host `/tmp/isaaclab` was not writable by this user. Each GPU job now
  binds a private node-local directory over container `/tmp`, including Ray temp.
  Independent jobs also receive separate home/cache directories.
- The asset mirror lacked `Isaac/Environments/Grid/default_environment.usd`.
  The downloader now seeds this original asset and follows its authored references.
  USD empty asset tokens `@@` required a parser correction to prevent adjacent
  metadata being treated as a download URL. Original USD/material contents are
  not rewritten.

Kit returned process status0 despite a failed Python runtime probe. Both the
production orchestration and short-job shell now require explicit passed JSON
reports. Smoke/capacity probes additionally check changed and finite model weights.
Regression checks cover the swallowed exception and empty USD token cases.
The local Python3.11 environment passes all37 offline tests, including transport
episode-clock/terminal-observation preservation and dead-child failure handling.

The failed eight jobs were resubmitted once as14021657–14021664; the original
C2 jobs14019299/14019304 are retained. All remain seed0, one GPU per job and the
original task-specific counts/budgets. They use an `afterok` dependency on the
latest real compute short test; consult `outputs/jobs/container_recovery_seed0.json`
and live Slurm state for the current dependency. Do not resubmit duplicates or
clear this dependency merely because Kit prints a GPU table or exits0.

Allocated debug job14021837 passed both stages on gpu3-9: 64environments, two
PPO updates in11.55s; original2048environments, two updates in4.83s. Both produced
changed, finite weights. The final shell emitted REAL_PPO_COMPUTE_SMOKE_PASSED,
and both JSON reports explicitly passed. These short timings include warmup and
must not be treated as steady-state long-training throughput.
All14 mirrored assets and their references are present. The ten production jobs'
afterok dependency is now satisfied. Each still runs its own task/config/smoke/
capacity checks before long training, including RLinf's native checks.

Inspection also aligned the RLinf checkpoint lookup with its original runner's
save layout: logger log_path / experiment_name / checkpoints. This does not change
PPO or the saved model. The later native compute checks below verified this lookup.

Short tests do not establish convergence, benchmark scores, hardware readiness,
or a long-run completion estimate. Final smoke/capacity report paths and timing
are recorded in the recovery manifest after verification.

## Native PPO and production restart

RLinf's EnvWorker initializes environments from a worker thread, while Isaac Sim
installs a main-thread SIGINT handler. The external adapter now uses RLinf's
official SubProcIsaacLabEnv spawned transport. The unchanged simulation/reward
implementation runs in the child main thread. Actions, terminal observations,
episode clocks and B2 curriculum steps are forwarded. The extension also registers
go2_policy in environment workers, which do not import actor model builders.

For remapped GPU ordinals, a sole permitted NVML device is passed by UUID for
ordinary PPO; RLinf requires integer IDs and receives the same permitted device's
NVML index. The host allocation is not broadened.

The debug QoS reached its shared-account eight-job limit. Native probes then
used step14021964.1 in the existing A2 allocation, with about44GiB free VRAM.
This short diagnostic overlap had separate home/cache/tmp paths. Exclude its
exact start/end interval from throughput comparisons. Both64- and2048-environment
native probes completed two updates, saved global_step_2 and passed finite-weight
checks. CPU inspection confirmed40 Adam steps and changed std in each checkpoint,
without initializing CUDA. The attached step completed successfully and the gate
watcher released all five native jobs. Evidence:
validation/compute_rlinf_14021964/{result,optimizer_gate}.json and
outputs/jobs/attached_native_gate.json.

Latest production IDs, resolved from container_recovery_seed0.json:
ordinary A1=14021657, A2=14021964, B1=14021965, B2=14021966, C2=14019299;
native A1/A2/B1/B2=14021967–14021970, C2=14019304. Older failed/replaced IDs
and probe failures remain as evidence. Check live scheduler and phase logs before
describing any particular production task as training or finished.
