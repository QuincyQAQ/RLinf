# 原项目配方与已发表结果：证据及未公开信息

## 这次的正式配方来源

源码：benchmark commit `743ac04d9543b04b7854f1100bfa0cc69c993106`。选择的五个脚本保存在 `config/reference.json` 的 `tasks.<task>.source`。启动命令直接从这些脚本最后的 `scripts/train.py` 调用抽取，不套用旧 hkust 移植版参数。

| 项目 | 本次采用的原始文件 | 要点 |
|---|---|---|
| A1 | `scripts/slurm/train_a1_legacy_exact_alice.sbatch` | Legacy Gym ID，额外 always-on 高度奖励 −5，2048×3000 |
| A2 | `scripts/slurm/train_a2_baseline_alice.sbatch` | 2048×1500，全向指令＋heading controller |
| B1 | `scripts/slurm/train_b1_baseline_alice.sbatch` | 2048×3000，仅 random_rough，原奖励 |
| B2 | `scripts/slurm/train_b2_baseline_posture_alice.sbatch` | 1024×2200，原成功 April15 配方，开启姿态奖励调度 |
| C2 | `scripts/slurm/train_c2_baseline_alice.sbatch` | **实际赋值默认 2048×3000**；头部注释示例的 1024×1500 不是当前默认 |

该选择复现的是公开**专用脚本默认配方**。不声称它就是所有已发表结果的完整历史训练命令。原项目泛用 `train_baselines_alice.sbatch` 另有默认 4096×1500；README 示例也有 1024×1500，两者没有覆盖专用脚本。

## 已发表结果选择了哪些模型

`benchmark/scripts/eval_completed_seeded.cmd` 是直接证据（seeds 0/1/2）：

| 项目 | 模型路径标记的环境数 | 被评估 checkpoint | 能确定什么 |
|---|---:|---|---|
| A1 | 1024 | `model_1499.pt` | Legacy 训练模型，评测时使用普通 A1 Gym ID |
| A2 | 1024 | `model_1499.pt` | 与专用 Slurm 的 2048 环境不同 |
| B1 | 1024 | `model_1499.pt` | 与专用 Slurm 的 2048×3000 不同 |
| B2 | 1024 | `model_1440.pt` | local April15 recheck；不能由文件名反推全部更新预算/调度分块 |
| C2 | 1024 | `model_2998.pt` | 名称含 `from_a2_refined`；A2 初始化及 refined 配置未在这一评测文件中完整公开 |

`results_seeded_1024` 中有逐回合评测 JSON，而没有这些历史运行的完整训练 checkpoint、`env.yaml`、`agent.yaml` 和容器版本锁。因此：**可以原样执行公开配方，不能凭结果目录名补出未公开训练配方。** 本目录未生成一个貌似精确、实为猜测的“published_1024 完全复现”训练入口。

C2 当前类的 docstring 写 70% gap＋30% rough，但实际 `_GAP_TERRAIN_GEN.sub_terrains` 只有 100% gap；以可执行代码为准，未按注释重写地形。课程学习是否开启也以最终实例化配置为准，runtime probe 导出整份配置，不凭描述擅自修改。

另一个历史计数陷阱：原 `--pretrained_checkpoint` 路径调用 `runner.load()` 后，只打印“iteration 0”，没有显式清空恢复的 iteration/optimizer。因此 C2 的 `model_2998.pt` 也不能直接解释成“在 C2 上从零训练了 3000 次”。本目录的默认 scratch 路线没有该歧义；若以后启用迁移初始化，必须记录实际加载状态。

## 采样和算法的继承来源

Isaac Lab v2.3.2：

- `source/isaaclab_tasks/isaaclab_tasks/manager_based/locomotion/velocity/velocity_env_cfg.py`：物理 dt、decimation、回合长度、传感器周期、指令重采样、观测顺序和噪声、基础事件与奖励。
- `.../config/go2/rough_env_cfg.py`：Go2 动作 scale、机器人 reset、mass 随机化及关闭 push 等覆盖。
- `.../config/go2/agents/rsl_rl_ppo_cfg.py`：原 24 步采样、actor/critic、归一化、5 epochs/4 mini-batches 和 PPO 超参数。
- `source/isaaclab_assets/isaaclab_assets/robots/unitree.py`：原 USD、初始关节角、DCMotor actuator、Kp=25/Kd=0.5。
- `source/isaaclab/isaaclab/envs/manager_based_env_cfg.py`：环境 seed 默认为 None；原训练器将其设置为 agent seed，原评测器没有这一步。

各任务额外覆盖来自原 `benchmark/envs/families/*`。完整源码保留，避免手工把奖励函数移植到 MuJoCo 后仍称完全一致。

## 软件环境不能冒充已核实

作者脚本只提供 `isaac-lab_2.3.2.sif` 文件名及集群 module 行，未公开该镜像的可下载地址、digest 或 pip freeze。选择的官方 tag 对应 Isaac Sim 5.1.0，`source/isaaclab_rl/setup.py` 声明 RSL-RL 3.1.2；本目录按此选定 CUDA PyTorch 2.7.0/cu128 等兼容约束，不沿用旧 NPU 的 RSL-RL 5.0.1。

原 `--distribution_safety_patch` 只在 `rsl_rl.modules.distribution` 提供指定类时生效。选定 3.1.2 的模块结构不同，原函数可能输出 unavailable 并跳过。保留原函数及日志，不能宣称已经拥有该补丁在未知原容器中的相同行为，也不能悄悄升级 RSL-RL 来追求补丁生效。A40 接入后须检查实际日志。

2026-11-19 已在 qli 登录节点下载官方容器，安装选定的核心依赖覆盖层，CPU 版本/导入检查、源码检查及 11 项离线测试通过，freeze/inspect 已保存。官方容器实际 Isaac Sim VERSION 为 `5.1.0-rc.19+release.26219.9c81211b.gl`。原镜像有 7 条依赖诊断，辅助层修复 4 条后，将不兼容的可选 URDF 转换工具隔离到独立 venv；训练入口及转换环境的 pip check 均通过，CPU USD→URDF 转换通过。原镜像及源码未改写，训练入口移除了 exporter prebundle 路径，保留训练 lxml 5.4.0；详见 `ENVIRONMENT_FIX_20261119.md` 和 `validation/container_dependency_audit.json`。官方资产已镜像并进行独立 CPU USD 静态解析，确认 12 个转动关节和引用闭包；这不证明 A40/PhysX/着色器运行可用。驱动/Vulkan、真实环境配置、64 环境及完整环境数 PPO 短测仍待计算节点验证。

`--asset-source mirror` 是可选的文件访问方式：仅将 Kit 资产根目录指向原文件镜像，不改写 USD/MDL、任务、奖励、PPO、采样或种子。默认 cloud 保留原 URL。操作性差异（容器临时目录、缓存挂载、辅助包修复和资源路径）均有明确记录，不声称恢复作者未公开的历史运行环境。

宿主 CPU、驱动与 Slurm 调度条件也未被公开镜像锁定。原 Slurm 请求每 GPU 4 个 CPU；这里不凭空添加 OpenMP 参数或 CPU MuJoCo workers。原训练器的 TF32/cudnn 全局开关保持原值，启动环境沿用源脚本的 `ACCEPT_EULA=Y`、`PRIVACY_CONSENT=Y`。这些设置不意味着跨硬件逐比特一致。

## 评测协议与用户主任务要求

- 原文档要求 cross-task 5×5；用户后来要求先主任务。入口默认 `--scope main` 是**执行范围调整**，`--scope matrix` 执行原完整矩阵；二者指标、环境、种子默认及采样方式一致。
- 256 环境、至少 1024 回合来自原 `eval_completed_seeded.cmd` 的默认值；原 `cross_eval.sh` 的快速示例另为 64 环境/256 回合，不混用。
- 训练 seeds 0/1/2 与评测环境 seed 是两件事。原评测没有显式 seed；目录 `_s0` 表示模型的训练 seed，不能因此断言评测 seed 也是 0。
- 原评测没有关闭观测噪声/课程或切换 Play 配置。本目录不额外关闭。
- 原 `envs/success.py` 定义的成功基于速度误差阈值、达标步数比例和不发生失败终止，没有显式检查真正穿越障碍。不能把其 success_rate 改名为 physical passage rate。
- JSON 回合数可能超过请求下限；核对逐回合列表并使用实际分母。进程退出码 0 而结果缺失、样本不足或 summary 与逐回合数据不一致，一律不能报告完成。

## 待 A40 完成

1. 软件依赖安装、Vulkan/图形能力和资产可访问性。
2. 每任务有效配置检查，以及 64 环境/2 次 PPO 接口短测。
3. **完整环境数**的初始化、显存容量与吞吐；不因为卡不够而静默降低 2048/1024。
4. seed 0 五任务正式训练、主任务原指标评测；之后再排 seed 1/2 或完整矩阵。
5. 保留这个 RSL-RL 基线，再为 RLinf PPO 建立独立目录/标记，逐项对齐同一 Isaac Lab MDP；不把框架改动称为算法实现完全相同。
