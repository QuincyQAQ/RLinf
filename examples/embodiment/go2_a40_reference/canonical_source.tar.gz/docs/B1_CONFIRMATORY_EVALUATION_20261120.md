# B1 fixed-policy repeat evaluation

One prespecified new evaluation seed, 45678, is applied to all three completed
B1 policies: repaired 3000-update PPO baseline, 4000-update RLinf-Huber, and
4000-update ordinary PPO. Each evaluates at least 2048 episodes with the same
256-environment evaluator. Training seed remains 0; no checkpoint is retrained
or selected using the repeat results.

The common action/history bound of +/-100, rewards, termination rules and
tracking criteria remain those used in completed comparison job14032301.
Each checkpoint is strictly loaded and checked for finite weights and positive
standard deviation before evaluation. SHA256 hashes must remain unchanged.
Saved episode successes must match the reported summary.

Report the new seed separately, retain original seeds23456/34567, and also
pool all retained episodes by counts. Do not replace earlier results or repeat
until RLinf wins. Original tracking counts are baseline2045/2048,
RLinf2044/2048, ordinary continuation2040/2048. This repeat probes evaluation
variability, not variation over independent training seeds.

The isolated single-A40 job uses the validated HPC container entrypoint,
four CPUs, 64GiB and a90-minute limit. Completion requires result.json with
status verified, not merely a successful Slurm submission or process exit.

Submitted job: **14036295**. CPU checkpoint validation passed before submission.
Read live outputs/b1_confirmatory_14036295 for progress and final evidence.
