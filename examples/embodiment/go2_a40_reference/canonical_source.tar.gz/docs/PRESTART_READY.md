# Go2 A40 开跑前交接：环境、资产与数据

工程位置：

- 本机：`/home/quincylee/code/Robotics/Unitree_GO2_A40_reference_20261118`
- qli：`/hpc2hdd/home/qli736/Unitree_GO2_A40_reference_20261118`

最终文件验收见 `validation/PRESTART_READY.json`。它只检查非仿真准备；正式 GPU/PhysX 验收必须在获配的 A40 计算节点执行。准备脚本没有申请资源、提交作业、启动 Kit/仿真或训练；旧本机、hkust 工程及训练保持原样。

## 这次训练需要什么数据

A1/A2/B1/B2/C2 是在线 PPO 任务，地形由原项目配置和随机种子生成，交互轨迹在训练时采集。五项 scratch 基线**不需要离线示范/SFT 数据集，也不加载旧模型**。需要的是原始任务代码、Isaac Sim/Isaac Lab 环境、机器人 USD、材质及贴图。

| 内容 | qli 工程内位置 | 用途 |
|---|---|---|
| 原任务与原奖励代码 | `benchmark/` | 正式基线，源码保持原样 |
| Isaac Lab v2.3.2 | `IsaacLab/` | 原 PhysX 环境及 Go2 配置 |
| 官方 SDK 镜像 | `containers/isaac-lab_2.3.2.sif` | 正式 GPU 容器 |
| 官方 Go2/地面/天空资产镜像 | `assets/isaac_sim_5.1/` | 提前下载原配置引用的资产 |
| hkust 参考资料 | `reference_archive/hkust_20261119/` | 旧 MuJoCo 模型、配置及评测归档 |
| 原始五任务参数和种子 | `config/reference.json` | 每项独立预算，种子 0/1/2；先 seed 0 |
| CPU 验收/依赖/资产报告 | `validation/` | 实际检查记录 |

hkust 参考资料已复制到 qli 和本机，约 26 MB，包含 **11 个可在 CPU 加载的模型**、对应配置/评测及历史成功 B2 模型。所有归档模型检查到的接口为 235 维观测、12 维动作，具体训练轮次见 `MODEL_CONTRACTS.json`。其中 native C2 是本次转存时已完成保存的 1200 次快照，其余转存模型为 2200 次。模型只是权重参考归档，不是完整优化器恢复包。

来源、原始路径和文件大小见 `TRANSFER_MANIFEST.json`；没有将 hkust 的 MuJoCo XML 替换原项目的 Isaac Sim USD，也没有将其他机器人的示范数据混入 Go2 基线。

## 依赖与容器

核心 PyTorch/RSL-RL/TensorDict/NumPy 等版本按 `config/reference.json` 验证。可修复的辅助依赖置于 `.extra_overlay`，通过 CPU 测试和新增冲突检查后才启用，精确版本见 `config/prestart-extra.lock.txt` 和安装报告。

原镜像有 7 条依赖诊断；辅助层修复 4 条，另外 3 条通过隔离不兼容的 USD 转换工具解决。训练入口保留 lxml 5.4.0，并从 Python 启动路径移除可选 URDF exporter 的 prebundle；转换工具在 `.usd_converter` 中使用 usd-core 25.2.post1 和 lxml 4.9.4。两边 `pip check` 均为 0，实际双连杆 USD→URDF 转换通过。原 SIF 未修改，其原始诊断完整保留；不能说原镜像本身被修复。SDK 自带 USD 仍由 Kit 扩展加载。详见 [修复记录](ENVIRONMENT_FIX_20261119.md)。

`.asset_tools` 是独立的 CPU USD 解析工具，仅用于资产镜像脚本。其 Python/动态库路径只在该工具的子进程内设置，`container_verify.json` 会检查它没有进入训练 Python 路径。GPU runtime probe 也会检查实际 USD 来源。

CPU 安装和检查复用 `containers/isaac-lab_2.3.2_unpacked/`，减少重复解压。GPFS 解包目录不能提供可写临时层，因此正式 GPU 入口使用原 SIF，并将临时解包放到节点本地 `/tmp` 或 `SLURM_TMPDIR`；Kit cache/data/logs 绑定到 `.isaacsim_cache/kit/`。CPU 文件系统预检结果见 `container_mount_preflight.json`。计算节点需要至少约 30 GiB 可用本地临时空间。

## 资产使用方式

资产镜像来自官方 Isaac Sim 5.1 S3 树，不改写 USD/MDL 内容；保留材质纹理和机器人几何引用，跳过不参与训练、可能引用内部开发服务器的预览缩略图。资产下载、引用闭包及 Go2 的 12 个转动关节用 CPU USD 工具检查，结果见 `asset_mirror.json`。着色器编译和 PhysX 加载仍需实际 GPU 短测。

默认 `--asset-source cloud` 保留原配置的资源 URL。可显式选择 `--asset-source mirror`，只追加 Kit 资产根目录参数，采样频率、环境数、奖励、PPO 和种子保持原配方。实际追加参数写入 `launch.json`。建议先在获配节点用镜像模式完成原入口自带的配置/小规模/全规模检查。

只查看计划（可在登录节点执行，不启动仿真）：

```bash
bash a40/hpc_environment.sh plan --seed 0 --asset-source mirror
```

## 未来正式启动

本次没有执行下列启动命令。已使用 `/opt/slurm/bin` 的 Slurm 23.02.3 实时核实：共享 A40 队列 `i64m1tga40u` 为 UP，用户 `qli736` 默认调度账户为 `root`，账户关联包含 `i64m1tga40u` QoS，分区允许该账户/QoS。`root` 是调度账户名，不是操作系统管理员权限。该 QoS 显示用户上限为 128 CPU、16 GPU（包括 A40 上限 16 卡），这是配置上限，不代表空闲数量或已获配资源。此前超时源于非登录 SSH 使用了 `/usr/bin` 的系统客户端。统一使用 `bash a40/slurm.sh`，不改全局配置；证据见 `cluster_scheduler_query.json`。尚未提交任务，未核实计费余额或保证排队时间。

- 队列：<https://docs.hpc.hkust-gz.edu.cn/docs/hpc12/slurm/queue/>
- 提交方式：<https://docs.hpc.hkust-gz.edu.cn/docs/hpc12/slurm/job2/>

启动模板为 `a40/a40_job.sbatch`：1 GPU、每 GPU 4 CPU、seed 0 五任务串行；原任务各自预算不统一为 2200。模板默认只打印计划，正式提交时明确启用执行。

```bash
# 未来：在确认账户/队列可用并决定开始训练后，从工程根目录提交。
GO2_MODE=suite GO2_SEED=0 GO2_ASSET_SOURCE=mirror GO2_EXECUTE=1 \
  bash a40/slurm.sh sbatch a40/a40_job.sbatch
```

已有授权 A40 allocation 时可直接运行：

```bash
bash a40/hpc_environment.sh run suite --seed 0 --asset-source mirror --execute
```

入口在正式训练前依次做：有效配置检查、64 环境/2 次 PPO、原完整 1024/2048 环境数/2 次 PPO 容量检查。正式训练重新从原 seed 初始化，短测权重不会继续使用。出错会停止并留下日志，不擅自降环境数或换奖励。每项训练结束只评估自己的主任务；之后再考虑完整矩阵和 RLinf 对照。
