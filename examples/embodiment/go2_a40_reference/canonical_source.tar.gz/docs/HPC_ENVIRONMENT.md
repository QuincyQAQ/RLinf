# qli 集群环境准备

远端目录：`/hpc2hdd/home/qli736/Unitree_GO2_A40_reference_20261118`。

本机入口：`bash a40/ssh_qli_direct.sh`。它仅对该条 SSH 连接使用物理 Wi-Fi 网卡和校园 DNS，不更改 Clash 或 SSH 全局配置。认证信息不存放在本项目。

## 当前路线

已验证 qli 登录节点为 Ubuntu 20.04 / glibc 2.31，集群提供 Apptainer 1.4.5。官方 `nvcr.io/nvidia/isaac-lab:2.3.2` 容器已下载完成（SIF 约 7.8 GiB），将保留的 benchmark / Isaac Lab 源码挂载进容器；修复依赖安装在本目录 `.python_overlay`，不修改系统 Python 或旧工程。

这不是作者未公开的 SIF 镜像，不能称为已恢复其历史二进制环境。软件约束和未知项仍见 `config/constraints.txt` 与 `REFERENCE_AUDIT.md`。

## 2026-11-19 实际验收结果

`HPC_SETUP_STATUS.json` 当前状态为 `cpu_environment_prepared`。核心版本与 CPU 导入/张量检查通过，源码检查通过，11 项离线测试通过；五项任务 seed 0 计划已生成。软件版本为 Python 3.11.13、PyTorch 2.7.0+cu128、torchvision 0.22.0+cu128、RSL-RL 3.1.2、TensorDict 0.8.3、NumPy 1.26.4、Gymnasium 1.2.1。官方镜像的实际 Isaac Sim VERSION 为 `5.1.0-rc.19+release.26219.9c81211b.gl`，不是从 pip metapackage 推测。

首次全局 `pip check` 有 7 条诊断。通过独立辅助覆盖层修复了 FastAPI/Starlette、PyJWT、docstring-parser 和 quadprog 四项问题，并验证相应 CPU 功能。另外 3 条 USD 转换工具冲突已通过独立 venv 与训练入口的 exporter 路径隔离解决；两边 pip check 均通过，实际双连杆 USD→URDF 转换通过，原始镜像未改。SDK 的 USD 由 Kit 扩展加载，资产解析用的独立 USD wheel 没有进入训练 Python 路径。原始诊断、差异报告、软件 freeze/inspect、源码检查、测试日志和启动计划均保存在远端及本机 `validation/`。GPU、模拟器和正式训练尚未启动。

官方资产镜像已完成：8 个文件、42,673,244 bytes，USD 解析确认 12 个转动关节、引用文件无缺失。原 SIF 的本地临时解包/缓存写入预检通过；GPFS 解包目录仅用于 CPU 检查。hkust 的模型与配置/评测已转存，详见 [开跑前交接](PRESTART_READY.md)。

首次安装曾使用 `a40/finish_hpc_setup.py` 后台流程，已经结束；以下是历史安装步骤，不是仍在等待：

1. 等待当前官方容器下载成功；等待最多四小时。
2. 在两个 CPU 的 affinity 内，以 nice 15 执行安装与 CPU 检查。
3. 检查选定软件版本、包来源、CPU 张量运算、RSL-RL 导入、原源码及离线测试，生成 seed 0 计划。另对比官方镜像和依赖覆盖层的全局 `pip check` 结果，不把原镜像已有冲突当成这次修改引入的问题，也不隐藏已有问题。
4. 成功后写入 `validation/HPC_SETUP_STATUS.json`；失败则写明错误和日志路径。不会静默更换版本或开始训练。

下载完成、安装完成和 GPU 验证通过是三个独立状态。当前先准备环境，**不申请 GPU、不提交 Slurm 作业、不在登录节点运行模拟器**。

## 查看进度

在远端工程目录运行：

```bash
cat validation/environment_worker_status.json
tail -n 30 validation/container_pull.log
tail -n 30 validation/environment_install.log
```

当前验收证据包括 `HPC_SETUP_STATUS.json`、`container_verify.json`、`container_dependency_audit.json`、`usd_converter_check.json`、`usd_isolation_ready.json`、`cluster_scheduler_query.json` 和 `cluster_offline_tests.txt`。训练及转换进程依赖检查均干净；未修改原始镜像，其原始诊断单独保留。历史 `known_image_conflicts` 记录不代表当前活动入口状态，CPU 检查也不代表 GPU 仿真已通过。

## 全镜像依赖问题的验收范围

首次安装在核心检查通过后，被全局 `pip check` 中断，失败记录保存在 `validation/*_attempt1.*` 和原安装日志。问题包括 Pink IK 的 quadprog、USD 转换工具的 usd-core/lxml、身份认证库的 PyJWT，以及 FastAPI/Starlette。独立 CPU 检查不覆盖这些功能的可用性。

Isaac Sim 自带 USD 运行库，未将 pip USD wheel 注入其训练路径。辅助依赖层曾因 lxml 降级与 dex-retargeting 要求冲突，被检查拦截且没有启用；保留镜像 lxml 5.4.0 后才通过验证。当前修复后的辅助版本记录在 `config/prestart-extra.lock.txt`，原镜像自身没有改写。验收在两个独立 Python 子进程中分别去掉/启用两层覆盖路径，保留全部诊断，**一旦出现新增依赖冲突仍然失败**。该状态仅是隔离修复前的历史结果；当前训练入口使用 `PYTHONEXE` 适配器，在官方 `python.sh` 设置环境之后移除可选 exporter prebundle，转换器在 `.usd_converter` 运行。详见 [依赖与调度器修复记录](ENVIRONMENT_FIX_20261119.md)。实际 Isaac Sim 环境创建和 PPO 短测仍是下一阶段必做检查。

原始与覆盖后的逐条结果保存在 `container_base_pip_check.txt` / `container_pip_check.txt`，差异保存在 `container_dependency_audit.json`。

后台流程失败时先看错误再修复；不要反复启动多个安装器。完成后可以手动重新验证：

```bash
bash a40/hpc_environment.sh verify
bash a40/hpc_environment.sh plan --seed 0
```

## 以后在已获配的 A40 任务内

以下命令要求已有授权的 Slurm allocation；本轮不执行。入口会保留调度器给定的 `CUDA_VISIBLE_DEVICES`，并验证实际 GPU 为 A40。

```bash
# 执行原任务前自动进行有效配置、64 环境短测、完整环境数容量检查。
bash a40/hpc_environment.sh run train --task A2 --seed 0 --execute

# 或五项依次执行；不要与上面的单项任务重复启动。
bash a40/hpc_environment.sh run suite --seed 0 --execute
```

仍需在计算节点实测：驱动/Vulkan、模型资产解析、235/12 观测动作、生效配置、64 环境 PPO 短测、1024/2048 环境完整容量与吞吐。CPU 包检查不能替代这些步骤。原项目源码、奖励、采样和种子不因容器安装而更改。
