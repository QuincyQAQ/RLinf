#!/usr/bin/env bash
#SBATCH --partition=emergency_gpua40
#SBATCH --qos=emergency_gpua40
#SBATCH --account=root
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:a40:1
#SBATCH --mem=64G
#SBATCH --time=06:00:00
#SBATCH --exclude=gpu3-13
set -euo pipefail
cd "${GO2_ABC_PROJECT:?}"
ABC_BATCH=data/go2_abc/AB_six_20261122
ABC_EXPERIMENT="${1:?experiment required}"
case "$ABC_EXPERIMENT" in A_baseline|A_ppo|A_rlinf|B_baseline|B_ppo|B_rlinf) ;; *) exit 2;; esac
git diff --exit-code HEAD
git rev-parse HEAD > "$ABC_BATCH/${ABC_EXPERIMENT}/source_commit.txt"
nvidia-smi --query-gpu=index,uuid,name --format=csv > "$ABC_BATCH/${ABC_EXPERIMENT}/gpu_${SLURM_JOB_ID}.csv"
ABC_ENTRY=/workspace/project/$ABC_BATCH/dispatch.py
if [[ "$ABC_EXPERIMENT" != *_baseline ]]; then
 for ABC_COUNT in 64 2048; do
  bash examples/embodiment/go2_abc/container.sh --python "$ABC_ENTRY" gate --experiment "$ABC_EXPERIMENT" --count "$ABC_COUNT"
 done
fi
bash examples/embodiment/go2_abc/container.sh --python "$ABC_ENTRY" full --experiment "$ABC_EXPERIMENT"
