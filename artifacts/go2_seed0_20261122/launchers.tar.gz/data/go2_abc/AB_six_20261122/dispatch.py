# Copyright 2026 The RLinf Authors.
# SPDX-License-Identifier: Apache-2.0
"""Launch the frozen A/B recipes in six separate Slurm allocations."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
sys.path.insert(0, str(PROJECT))
COMMIT = "e8815cac3b3abecedf13e9310aa9661baa6d1043"
EXPERIMENTS = [f"{task}_{group}" for task in "AB" for group in ("baseline", "ppo", "rlinf")]


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def prepare(experiment):
    data = ROOT / experiment
    data.mkdir(exist_ok=True)
    for name in ("models", "raw"):
        link = data / name
        if not link.exists():
            link.symlink_to(Path("../..") / name, target_is_directory=True)
    os.environ["GO2_ABC_DATA"] = str(data)
    return data


def execute(experiment, stage, count):
    from examples.embodiment.go2_abc.prepare_data import HERE
    from examples.embodiment.go2_abc.reproduce import check_weights

    data = prepare(experiment)
    task, group = experiment.split("_")
    runtime = Path(os.environ["GO2_ABC_RUNTIME"])
    directory = data / ("full_driver" if stage == "full" else f"gate_{count}")
    directory.mkdir(exist_ok=False)
    label = f"AB6_{experiment}_{count}_{os.environ['SLURM_JOB_ID']}"
    env = dict(os.environ, RLINF_EXT_MODULE="examples.embodiment.go2_abc.extension",
               RAY_ADDRESS="local", RAY_TMPDIR=f"/tmp/{label}")
    env["PYTHONPATH"] = os.pathsep.join([str(PROJECT), str(runtime / "a40"),
                                         str(runtime / "benchmark"), env.get("PYTHONPATH", "")])
    if task == "B":
        env["GO2_B1_NUMERIC_GUARD"] = "1"
    if stage == "full":
        command = [sys.executable, "-m", "examples.embodiment.go2_abc.run",
                   "--experiment", experiment, "--execute"]
    elif group == "rlinf":
        command = [sys.executable, str(PROJECT / "examples/embodiment/train_embodied_agent.py"),
                   "--config-path", str(HERE / "config"), "--config-name", experiment,
                   f"env.train.total_num_envs={count}", f"actor.micro_batch_size={count * 6}",
                   f"actor.global_batch_size={count * 6}", "runner.max_epochs=2", "runner.max_steps=2",
                   "runner.save_interval=1", f"runner.logger.log_path={directory}",
                   "runner.logger.experiment_name=training",
                   f"env.train.validation_output={directory}/environment"]
    else:
        if group != "ppo":
            raise ValueError("Baseline evaluation has no learner gate")
        config = json.loads((HERE / f"config/{experiment}.json").read_text())
        env.update(config["env"])
        def resolve(value):
            return value.replace("${GO2_ABC_DATA}", str(data)).replace("${GO2_ABC_RUNTIME}", str(runtime))
        argv = list(map(resolve, config["argv"]))
        for flag, value in (("--num_envs", count), ("--max_iterations", 2),
                            ("--experiment_name", label), ("--run_name", label)):
            argv[argv.index(flag) + 1] = str(value)
        command = [sys.executable, resolve(config["entry"]), *argv]
    record = {"experiment": experiment, "stage": stage, "num_envs": count,
              "source_commit": COMMIT, "training_seed": 0, "evaluation_seeds": [23456, 34567],
              "job_id": os.environ["SLURM_JOB_ID"], "argv": command, "status": "running"}
    write(directory / "command.json", record)
    write(data / "status.json", record)
    try:
        with (directory / "console.log").open("w") as log:
            subprocess.run(command, cwd=PROJECT, env=env, stdout=log,
                           stderr=subprocess.STDOUT, check=True)
        if stage == "gate":
            if group == "rlinf":
                checkpoint = directory / "training/checkpoints/global_step_2/actor/model_state_dict/full_weights.pt"
            else:
                checkpoints = list((runtime / f"benchmark/logs/rsl_rl/{label}").glob("*/model_*.pt"))
                checkpoint = max(checkpoints, key=lambda path: path.stat().st_mtime_ns)
            record["weights"] = check_weights(checkpoint, data / f"models/{task}/baseline.pt", group == "rlinf")
        else:
            evaluations = []
            for seed in (23456, 34567):
                records = [json.loads(path.read_text()) for path in
                           (data / f"runs/{experiment}/evaluation/{seed}").rglob("*.json")]
                records = [value for value in records if isinstance(value, dict) and "episodes" in value]
                if len(records) != 1 or len(records[0]["episodes"]) < 1024:
                    raise RuntimeError(f"Incomplete evaluation for seed {seed}")
                if len(records[0]["episodes"]) != records[0]["summary"]["num_episodes"]:
                    raise RuntimeError(f"Episode count mismatch for seed {seed}")
                evaluations.append({"seed": seed, "summary": records[0]["summary"]})
            record["evaluations"] = evaluations
        record["status"] = "completed"
        write(directory / "completed.json", record)
    except BaseException as exc:
        record.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        write(data / "status.json", record)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("cpu-audit", "gate", "full"))
    parser.add_argument("--experiment", choices=EXPERIMENTS)
    parser.add_argument("--count", choices=(64, 2048), type=int, default=2048)
    args = parser.parse_args()
    actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=PROJECT, text=True).strip()
    if actual != COMMIT:
        raise RuntimeError(f"Expected {COMMIT}, found {actual}")
    subprocess.run(["git", "diff", "--exit-code", "HEAD"], cwd=PROJECT, check=True)
    if args.mode == "cpu-audit":
        import torch
        from hydra import compose, initialize_config_dir
        from omegaconf import OmegaConf
        from examples.embodiment.go2_abc.audit import audit
        from examples.embodiment.go2_abc.prepare_data import HERE
        from examples.embodiment.go2_abc.run import launch
        result = audit(ROOT.parent)
        for experiment in EXPERIMENTS:
            prepare(experiment)
            if experiment.endswith("rlinf"):
                with initialize_config_dir(config_dir=str(HERE / "config"), version_base=None):
                    config = compose(config_name=experiment)
                    resolved = OmegaConf.to_container(config, resolve=True)
                if resolved["actor"]["seed"] != 0 or resolved["runner"]["max_steps"] != 1000:
                    raise RuntimeError("Unexpected seed or training budget")
                write(ROOT / experiment / "resolved_config.json", resolved)
            launch(experiment, False)
        if torch.cuda.is_initialized():
            raise RuntimeError("CPU preflight initialized CUDA")
        write(ROOT / "cpu_audit.json", dict(result, source_commit=COMMIT, cuda_initialized=False))
    else:
        if not args.experiment or not os.environ.get("SLURM_JOB_ID"):
            raise RuntimeError("An experiment and A40 Slurm allocation are required")
        execute(args.experiment, args.mode, args.count)


if __name__ == "__main__":
    main()
