#!/usr/bin/env bash
set -euo pipefail
source /hpc2hdd/home/qli736/Unitree_GO2_A40_ABC_repro_C_20261122/data/go2_abc/scheduler/environment.sh
cd "$GO2_ABC_PROJECT"
ABC_BATCH=data/go2_abc/AB_six_20261122
exec 9>"$ABC_BATCH/submission.lock"
flock -n 9
[[ -s "$ABC_BATCH/cpu_audit.json" ]]
[[ ! -e "$ABC_BATCH/jobs.tsv" ]]
[[ "$(git rev-parse HEAD)" == e8815cac3b3abecedf13e9310aa9661baa6d1043 ]]
git diff --exit-code HEAD
for ABC_EXPERIMENT in A_baseline A_ppo A_rlinf B_baseline B_ppo B_rlinf; do
 [[ ! -e "$ABC_BATCH/$ABC_EXPERIMENT/runs/$ABC_EXPERIMENT" ]]
 if [[ "$ABC_EXPERIMENT" == *_ppo ]]; then
  [[ ! -e "$GO2_ABC_RUNTIME/benchmark/logs/rsl_rl/$ABC_EXPERIMENT" ]]
 fi
done
printf 'experiment\tjob_id\n' > "$ABC_BATCH/jobs.tsv"
for ABC_EXPERIMENT in A_baseline A_ppo A_rlinf B_baseline B_ppo B_rlinf; do
 ABC_TIME=06:00:00
 if [[ "$ABC_EXPERIMENT" == *_baseline ]]; then ABC_TIME=01:00:00; fi
 ABC_JOB=$(/opt/slurm/bin/sbatch --parsable --export=ALL --time="$ABC_TIME" \
  --job-name="go2_${ABC_EXPERIMENT}_e881_s0" \
  --output="$GO2_ABC_PROJECT/$ABC_BATCH/$ABC_EXPERIMENT/slurm-%j.out" \
  --error="$GO2_ABC_PROJECT/$ABC_BATCH/$ABC_EXPERIMENT/slurm-%j.err" \
  "$ABC_BATCH/run.sbatch" "$ABC_EXPERIMENT")
 printf '%s\t%s\n' "$ABC_EXPERIMENT" "$ABC_JOB" | tee -a "$ABC_BATCH/jobs.tsv"
done
/opt/slurm/bin/squeue -u qli736 -o '%.18i %.30j %.10T %.12M %.30R'
