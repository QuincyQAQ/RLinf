# Copyright 2026 The RLinf Authors.
# SPDX-License-Identifier: Apache-2.0
"""Compare an independent C continuation against completed job 14060127."""

import hashlib
import json
import os
import re
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parents[2]))
PREVIOUS = ROOT.parent / "new_single_20261122"
RELATIVE = Path("repeat1/runs/C_rlinf")


def summarize(root):
    run = root / RELATIVE
    console = (run / "training/console.log").read_text(errors="replace")
    assert re.search(r"Global Step:\s*1000/1000", console)
    episodes = []
    records = {}
    for seed in (23456, 34567):
        candidates = []
        for path in (run / f"evaluation/{seed}").rglob("*.json"):
            record = json.loads(path.read_text())
            if isinstance(record, dict) and "episodes" in record:
                candidates.append(record)
        assert len(candidates) == 1
        record = candidates[0]
        assert len(record["episodes"]) == record["summary"]["num_episodes"] == 1024
        assert all(e["episode_success"] is not None and e["physical_obstacle_passage"] is not None
                   for e in record["episodes"])
        records[seed] = record
        episodes.extend(record["episodes"])
    count = len(episodes)
    tracking = sum(bool(e["episode_success"]) for e in episodes)
    passages = sum(bool(e["physical_obstacle_passage"]) for e in episodes)
    return {
        "training_iterations": 1000,
        "episodes": count,
        "tracking_successes": tracking,
        "tracking_rate": tracking / count,
        "passage_successes": passages,
        "passage_rate": passages / count,
        "linear_error": sum(e["mean_lin_vel_error_xy"] for e in episodes) / count,
        "angular_error": sum(e["mean_ang_vel_error_z"] for e in episodes) / count,
        "policy_sha256": hashlib.sha256((run / "policy.pt").read_bytes()).hexdigest(),
    }, records


def main():
    from examples.embodiment.go2_abc.reproduce import check_weights

    previous, old_records = summarize(PREVIOUS)
    current, new_records = summarize(ROOT)
    assert previous["passage_successes"] == 925
    checkpoints = []
    for step in range(50, 1001, 50):
        suffix = RELATIVE / f"checkpoints/global_step_{step}/actor/model_state_dict/full_weights.pt"
        paths = [folder / suffix for folder in (PREVIOUS, ROOT)]
        check_weights(paths[1], ROOT.parent / "models/C/baseline.pt", True)
        states = [torch.load(p, map_location="cpu", weights_only=False) for p in paths]
        assert states[0].keys() == states[1].keys()
        differences = {
            key: float((states[0][key] - states[1][key]).abs().max())
            for key in states[0]
            if not torch.equal(states[0][key], states[1][key])
        }
        checkpoints.append({"step": step, "weights_exact_match": not differences,
                            "max_absolute_differences": differences})
    evaluations = [
        {"seed": seed,
         "episodes_exact_match": old_records[seed]["episodes"] == new_records[seed]["episodes"],
         "previous_summary": old_records[seed]["summary"],
         "current_summary": new_records[seed]["summary"]}
        for seed in (23456, 34567)
    ]
    exact = all(c["weights_exact_match"] for c in checkpoints)
    exact = exact and all(e["episodes_exact_match"] for e in evaluations)
    report = {
        "status": "completed",
        "reproducibility": "exact_match" if exact else "mismatch",
        "source_commit": (ROOT / "source_commit.txt").read_text().strip(),
        "training_seed": 0,
        "evaluation_seeds": [23456, 34567],
        "previous_job_id": 14060127,
        "job_id": os.environ["SLURM_JOB_ID"],
        "previous": previous,
        "current": current,
        "passage_delta_percentage_points": 100 * (current["passage_rate"] - previous["passage_rate"]),
        "checkpoints": checkpoints,
        "evaluations": evaluations,
    }
    for name in ("comparison.json", "status.json"):
        temporary = ROOT / (name + ".tmp")
        temporary.write_text(json.dumps(report, indent=2) + "\n")
        temporary.replace(ROOT / name)


if __name__ == "__main__":
    main()
