#!/usr/bin/env bash
#SBATCH --partition=emergency_gpua40
#SBATCH --qos=emergency_gpua40
#SBATCH --account=root
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --gres=gpu:a40:1
#SBATCH --mem=64G
#SBATCH --time=04:00:00
#SBATCH --exclude=gpu3-13
#SBATCH --job-name=go2_C_new_repeat_s0
set -euo pipefail
cd "${GO2_ABC_PROJECT:?}"
ABC_SINGLE=data/go2_abc/new_independent_20261122
git diff --exit-code HEAD
git rev-parse HEAD > "$ABC_SINGLE/source_commit.txt"
sha256sum "$ABC_SINGLE/verify_seed0.py" > "$ABC_SINGLE/driver.sha256"
nvidia-smi --query-gpu=index,uuid,name --format=csv > "$ABC_SINGLE/gpu_${SLURM_JOB_ID}.csv"
ABC_ENTRY=/workspace/project/$ABC_SINGLE/verify_seed0.py
bash examples/embodiment/go2_abc/container.sh --python "$ABC_ENTRY" cpu-audit
for ABC_COUNT in 64 1024; do
 bash examples/embodiment/go2_abc/container.sh --python "$ABC_ENTRY" run --stage gate --count "$ABC_COUNT" --repeat 1
done
bash examples/embodiment/go2_abc/container.sh --python "$ABC_ENTRY" run --stage full --repeat 1
bash examples/embodiment/go2_abc/container.sh --python /workspace/project/$ABC_SINGLE/compare_previous.py
