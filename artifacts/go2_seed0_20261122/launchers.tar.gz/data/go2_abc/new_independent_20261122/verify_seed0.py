"""Run the current C learner twice and audit weights and evaluation episodes."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
sys.path.insert(0, str(PROJECT))
SOURCE_DATA = ROOT.parent
EXPECTED_COMMIT = 'e8815cac3b3abecedf13e9310aa9661baa6d1043'


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def data_for(repeat):
    data = ROOT / f'repeat{repeat}'
    data.mkdir(exist_ok=True)
    for name in ('models', 'raw'):
        link = data / name
        if not link.exists():
            link.symlink_to(SOURCE_DATA / name, target_is_directory=True)
    return data


def execute(args):
    from examples.embodiment.go2_abc.prepare_data import HERE
    data = data_for(args.repeat)
    env = dict(os.environ, GO2_ABC_DATA=str(data),
               RLINF_EXT_MODULE='examples.embodiment.go2_abc.extension',
               RAY_ADDRESS='local',
               RAY_TMPDIR=f'/tmp/repeat_{args.repeat}_{args.stage}_{args.count}')
    env['PYTHONPATH'] = os.pathsep.join([str(PROJECT), os.environ.get('PYTHONPATH', '')])
    if args.stage == 'full':
        command = [sys.executable, '-m', 'examples.embodiment.go2_abc.run',
                   '--experiment', 'C_rlinf', '--execute']
        directory = data / 'full_driver'
    else:
        directory = data / f'gate_{args.count}'
        command = [sys.executable, str(PROJECT / 'examples/embodiment/train_embodied_agent.py'),
                   '--config-path', str(HERE / 'config'), '--config-name', 'C_rlinf',
                   f'env.train.total_num_envs={args.count}',
                   f'actor.micro_batch_size={args.count * 6}',
                   f'actor.global_batch_size={args.count * 6}',
                   'runner.max_epochs=2', 'runner.max_steps=2', 'runner.save_interval=1',
                   f'runner.logger.log_path={directory}',
                   'runner.logger.experiment_name=training',
                   f'env.train.validation_output={directory}/environment']
    directory.mkdir(parents=True, exist_ok=False)
    write(directory / 'command.json', {'argv': command, 'training_seed': 0,
          'source_commit': EXPECTED_COMMIT, 'data': str(data)})
    write(ROOT / 'status.json', {'status': 'running', 'stage': args.stage,
          'repeat': args.repeat, 'num_envs': args.count, 'job_id': os.environ['SLURM_JOB_ID']})
    with (directory / 'console.log').open('w') as log:
        subprocess.run(command, cwd=PROJECT, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=14400)
    write(directory / 'completed.json', {'status': 'completed'})


def compare(args):
    import torch
    from examples.embodiment.go2_abc.reproduce import check_weights
    folders = [data_for(repeat) for repeat in (1, 2)]
    if args.stage == 'full':
        relative = Path('runs/C_rlinf/checkpoints')
        steps = range(50, 1001, 50)
    else:
        relative = Path(f'gate_{args.count}/training/checkpoints')
        steps = (1, 2)
    comparisons = []
    for step in steps:
        suffix = f'global_step_{step}/actor/model_state_dict/full_weights.pt'
        paths = [folder / relative / suffix for folder in folders]
        for path in paths:
            check_weights(path, SOURCE_DATA / 'models/C/baseline.pt', True)
        states = [torch.load(path, map_location='cpu', weights_only=False) for path in paths]
        assert states[0].keys() == states[1].keys()
        differences = {key: float((states[0][key] - states[1][key]).abs().max())
                       for key in states[0] if not torch.equal(states[0][key], states[1][key])}
        comparisons.append({'step': step, 'weights_exact_match': not differences,
                            'max_absolute_differences': differences})
    evaluations = []
    if args.stage == 'full':
        for seed in (23456, 34567):
            records = []
            for folder in folders:
                candidates = [json.loads(path.read_text()) for path in
                              (folder / f'runs/C_rlinf/evaluation/{seed}').rglob('*.json')]
                candidates = [record for record in candidates if isinstance(record, dict) and 'episodes' in record]
                assert len(candidates) == 1
                record = candidates[0]
                assert len(record['episodes']) >= 1024
                assert len(record['episodes']) == record['summary']['num_episodes']
                records.append(record)
            evaluations.append({'seed': seed,
                'episodes_exact_match': records[0]['episodes'] == records[1]['episodes'],
                'summaries': [record['summary'] for record in records]})
    passed = all(item['weights_exact_match'] for item in comparisons)
    passed = passed and all(item['episodes_exact_match'] for item in evaluations)
    report = {'status': 'passed' if passed else 'mismatch', 'training_seed': 0,
              'stage': args.stage, 'num_envs': args.count,
              'source_commit': EXPECTED_COMMIT, 'checkpoints': comparisons,
              'evaluations': evaluations, 'job_id': os.environ['SLURM_JOB_ID']}
    write(ROOT / f'comparison_{args.stage}_{args.count}.json', report)
    write(ROOT / 'status.json', report)
    if not passed:
        raise RuntimeError('Repeated seed-0 runs diverged; inspect comparison and retained logs')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('run', 'compare', 'cpu-audit'))
    parser.add_argument('--stage', choices=('gate', 'full'), default='gate')
    parser.add_argument('--repeat', choices=(1, 2), type=int, default=1)
    parser.add_argument('--count', choices=(64, 1024), type=int, default=1024)
    args = parser.parse_args()
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=PROJECT, text=True).strip()
    assert actual == EXPECTED_COMMIT, (actual, EXPECTED_COMMIT)
    if args.mode == 'cpu-audit':
        from examples.embodiment.go2_abc.audit import audit
        import torch
        result = audit(SOURCE_DATA)
        result.update(source_commit=actual, cuda_initialized=torch.cuda.is_initialized())
        assert not result['cuda_initialized']
        write(ROOT / 'cpu_audit.json', result)
        return
    assert os.environ.get('SLURM_JOB_ID'), 'An allocated A40 job is required'
    try:
        execute(args) if args.mode == 'run' else compare(args)
    except BaseException as exc:
        write(ROOT / 'failure.json', {'error': f'{type(exc).__name__}: {exc}',
              'stage': args.stage, 'mode': args.mode, 'repeat': args.repeat})
        raise


if __name__ == '__main__':
    main()
